#!/bin/bash
# =====================================================================
# cart-ni-isko-diskalert.sh - Script 6: Disk alert
#
# Purpose : Warns clearly when the use of any mounted disk passes the
#           threshold the user sets (--threshold N, default DISK_THRESHOLD,
#           80 %) and then exits with a non-zero status (3). After the disk
#           check it also looks for other risks and rates each HIGH, MEDIUM or
#           LOW: SSH password guessing, sign-in abuse and probing of the
#           website, services down, missing or failed backups, unsafe
#           permissions or settings, and changed system files (compared with a
#           saved baseline). Alerts go to the screen and to alerts.log; with
#           --notify, HIGH alerts also go to every logged-in terminal (wall).
# Authors : Group G01
#           Brucelo, Alyssa Mae B.; Ebuenga, Kristel Ann B.;
#           Fenis, Austin B.; Marfil, John Marvin G.
# Usage   : sudo ./cart-ni-isko-diskalert.sh [--threshold N] [--disk-only]
#           [--baseline] [--minutes N] [--notify] [--install-timer] [--help]
# Needs   : Script 1 already run. Only reads and reports; it fixes nothing.
#           (Earlier name: cart-ni-isko-riskalert.sh.)
# AI note : Drafted with help from Claude (Anthropic AI). Every line was
#           reviewed, tested and can be explained by the group (Section 5.6).
# =====================================================================

set -o pipefail          # a pipe fails if ANY command in it fails
umask 077                # state files and baseline: root only

SCRIPT_NAME="$(basename "$0")"
CONF="${CARTNIISKO_CONF:-/etc/cart-ni-isko/cart-ni-isko.conf}"   # same variable as Script 1
STATE_DIR="${CARTNIISKO_STATE:-/var/lib/cart-ni-isko}"     # baseline and alert state
HIGH=0; MEDIUM=0; LOW=0

usage() {
  cat <<EOF
Usage: sudo ./$SCRIPT_NAME [OPTION]...

Warns clearly when any disk is fuller than the threshold (in percent) and
exits with status 3. Then checks the Cart ni Isko server for other risks and
prints one ALERT line per risk, rated HIGH, MEDIUM or LOW. Each alert is
written to alerts.log.

Options:
  --threshold N     disk alert threshold in percent, 1 to 99
                    (default DISK_THRESHOLD in the config, 80)
  --disk-only       check the disks only, skip the other risk checks
  --baseline        save the current state of the watched system files as the
                    trusted baseline (run once after setup and after every
                    change you made on purpose), then check as usual
  --minutes N       look at the last N minutes of logs (default RISK_WINDOW_MIN, 60)
  --notify          send HIGH alerts to logged-in users (wall) and ALERT_EMAIL
  --install-timer   also run this check with --notify every 15 minutes (systemd)
  -h, --help        show this help and exit

Examples:
  sudo ./$SCRIPT_NAME --threshold 75
  sudo ./$SCRIPT_NAME --threshold 90 --disk-only
  sudo ./$SCRIPT_NAME --baseline

Exit status: 0 every disk below the threshold and no HIGH or MEDIUM risk,
             1 error, 2 bad option,
             3 DISK ALERT: at least one disk at or above the threshold,
             4 disks below the threshold, but a HIGH or MEDIUM risk found.
EOF
}

die() { echo "ERROR: $*" >&2; exit 1; }

load_config() {          # same rules as Scripts 1 to 5
  [ -f "$CONF" ] || die "$CONF not found. Run Script 1 (cart-ni-isko-install.sh) first."
  [ "$(stat -c '%U:%a' "$CONF")" = "root:600" ] ||
    die "$CONF must be owner root, mode 600: sudo chown root:root $CONF && sudo chmod 600 $CONF"
  # shellcheck source=/dev/null
  . "$CONF"
  APP_DIR="${APP_DIR:-/var/www/cart-ni-isko}"
  BACKUP_DIR="${BACKUP_DIR:-/var/backups/cart-ni-isko}"
  APP_NAME="${APP_NAME:-cart-ni-isko}"
  WEB_USER="${WEB_USER:-www-data}"; WEB_GROUP="${WEB_GROUP:-www-data}"
  LOG_DIR="${LOG_DIR:-${REPORT_DIR:-/var/log/cart-ni-isko-toolkit}}"   # Script 1 creates REPORT_DIR
  PHP_VER="${PHP_VER:-8.5}"
  HEALTH_BASE_URL="${HEALTH_BASE_URL:-http://127.0.0.1}"
  NGINX_ACCESS_LOG="${NGINX_ACCESS_LOG:-/var/log/nginx/${APP_NAME}_access.log}"
  SERVICES="${SERVICES:-php$PHP_VER-fpm nginx $APP_NAME-scheduler}"
  API_CHECK_PATH="${API_CHECK_PATH:-/api/products/filter}"
  DISK_WARN_PCT="${DISK_WARN_PCT:-80}"; DISK_FAIL_PCT="${DISK_FAIL_PCT:-90}"
  DISK_THRESHOLD="${DISK_THRESHOLD:-${DISK_ALERT_PCT:-80}}"   # set in Script 1's config
  DB_CONF="${DB_CONF:-$(dirname "$CONF")/db.conf}"   # written by Script 1
  MEM_FAIL_PCT="${MEM_FAIL_PCT:-95}"
  BACKUP_MAX_AGE_H="${BACKUP_MAX_AGE_H:-26}"
  RISK_WINDOW_MIN="${RISK_WINDOW_MIN:-60}"
  SSH_FAIL_LIMIT="${SSH_FAIL_LIMIT:-10}"      # failed SSH logins per window
  LOGIN_FAIL_LIMIT="${LOGIN_FAIL_LIMIT:-30}"  # refused app logins per window
  PROBE_LIMIT="${PROBE_LIMIT:-20}"            # requests for attack paths per window
  FLOOD_LIMIT="${FLOOD_LIMIT:-3000}"          # requests from one IP per window
  ALERT_REPEAT_MIN="${ALERT_REPEAT_MIN:-60}"  # same alert logged/sent again after
  ALERT_EMAIL="${ALERT_EMAIL:-}"
}

# ---------------------------------------------------------------------
# 1. Options
# ---------------------------------------------------------------------
BASELINE="no"; NOTIFY="no"; TIMER="no"; MINUTES=""; THRESHOLD=""; DISK_ONLY="no"
while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help)       usage; exit 0 ;;
    --baseline)      BASELINE="yes" ;;
    --minutes)       [[ "${2:-}" =~ ^[1-9][0-9]*$ ]] || { echo "ERROR: --minutes needs a whole number" >&2; usage >&2; exit 2; }
                     MINUTES="$2"; shift ;;
    --threshold)     [[ "${2:-}" =~ ^[1-9][0-9]?$ ]] || { echo "ERROR: --threshold needs a percentage from 1 to 99" >&2; usage >&2; exit 2; }
                     THRESHOLD="$2"; shift ;;
    --disk-only)     DISK_ONLY="yes" ;;
    --notify)        NOTIFY="yes" ;;
    --install-timer) TIMER="yes" ;;
    *)               echo "ERROR: unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

# ---------------------------------------------------------------------
# 2. Requirement checks
# ---------------------------------------------------------------------
[ "$(id -u)" -eq 0 ] || die "this script must be run as root: sudo ./$SCRIPT_NAME"
load_config
MINUTES="${MINUTES:-$RISK_WINDOW_MIN}"
THRESHOLD="${THRESHOLD:-$DISK_THRESHOLD}"
[[ "$THRESHOLD" =~ ^[1-9][0-9]?$ ]] || die "DISK_THRESHOLD must be a percentage from 1 to 99 in $CONF"
for v in DISK_WARN_PCT DISK_FAIL_PCT MEM_FAIL_PCT BACKUP_MAX_AGE_H RISK_WINDOW_MIN SSH_FAIL_LIMIT \
         LOGIN_FAIL_LIMIT PROBE_LIMIT FLOOD_LIMIT ALERT_REPEAT_MIN; do
  [[ "${!v}" =~ ^[0-9]+$ ]] || die "$v must be a whole number in $CONF"
done
for t in curl awk sha256sum stat df free; do
  command -v "$t" >/dev/null || die "the command '$t' is missing"
done
mkdir -p "$STATE_DIR" "$LOG_DIR" && chmod 700 "$STATE_DIR" && chmod 750 "$LOG_DIR" ||
  die "cannot create $STATE_DIR or $LOG_DIR"
WORK="$(mktemp -d /tmp/cart-ni-isko-diskalert.XXXXXX)"
trap 'rm -rf -- "$WORK"' EXIT
touch "$STATE_DIR/alert-state"

# ---------------------------------------------------------------------
# 3. Raising an alert
# ---------------------------------------------------------------------
# alert LEVEL ID MESSAGE: ID is a short fixed name used to avoid repeating the
# same alert in the log and in notifications more than once per ALERT_REPEAT_MIN.
alert() {
  local level="$1" id="$2" msg="$3" now last
  case "$level" in HIGH) HIGH=$((HIGH + 1)) ;; MEDIUM) MEDIUM=$((MEDIUM + 1)) ;; *) LOW=$((LOW + 1)) ;; esac
  printf '  ALERT %-6s %s\n' "$level" "$msg"
  now="$(date +%s)"
  last="$(awk -v i="$id" '$1 == i {print $2}' "$STATE_DIR/alert-state")"
  if [ -z "$last" ] || [ $((now - last)) -ge $((ALERT_REPEAT_MIN * 60)) ]; then
    echo "$(date '+%F %T') $level $id $msg" >>"$LOG_DIR/alerts.log"
    [ "$level" = "HIGH" ] && echo "$level $msg" >>"$WORK/notify"
    grep -v "^$id " "$STATE_DIR/alert-state" >"$WORK/state"; echo "$id $now" >>"$WORK/state"
    cat "$WORK/state" >"$STATE_DIR/alert-state"
  fi
}

# ---------------------------------------------------------------------
# 4. File integrity baseline
# ---------------------------------------------------------------------
watched_files() {        # the files whose change could mean a break-in
  printf '%s\n' /etc/passwd /etc/group /etc/shadow /etc/sudoers /etc/ssh/sshd_config \
    "$CONF" "$DB_CONF" "$APP_DIR/backend/.env" "$APP_DIR/backend/public/index.php" \
    "$APP_DIR/backend/routes/api.php" "$APP_DIR/frontend/dist/index.html"
  ls -1 /etc/sudoers.d/* /etc/ssh/sshd_config.d/* /etc/nginx/sites-enabled/* \
    /etc/systemd/system/cart-ni-isko-* /root/.ssh/authorized_keys /home/*/.ssh/authorized_keys 2>/dev/null
}
BASE_FILE="$STATE_DIR/integrity.sha256"
if [ "$BASELINE" = "yes" ]; then
  watched_files | while read -r f; do [ -f "$f" ] && sha256sum "$f"; done >"$BASE_FILE"
  chmod 600 "$BASE_FILE"
  echo "==> Baseline saved: $(wc -l <"$BASE_FILE") files in $BASE_FILE"
  echo "$(date '+%F %T') BASELINE saved files=$(wc -l <"$BASE_FILE")" >>"$LOG_DIR/alerts.log"
fi

# ---------------------------------------------------------------------
# 5. Disk alert: every mounted disk against the user's threshold
# ---------------------------------------------------------------------
echo "Cart ni Isko disk alert and risk check   $(date '+%F %T')"
echo
echo "Disk use (threshold $THRESHOLD%):"
DISK_OVER=0
# df -P: one line per disk; -x leaves out memory-only and image file systems
while read -r used avail mnt; do
  pct="${used%\%}"
  if [ "$pct" -ge "$THRESHOLD" ]; then
    printf '  OVER %3s%% used  %6s free  %s\n' "$pct" "$avail" "$mnt"
    DISK_OVER=$((DISK_OVER + 1))
    echo "$mnt $pct $avail" >>"$WORK/over"
  else
    printf '  ok   %3s%% used  %6s free  %s\n' "$pct" "$avail" "$mnt"
  fi
done < <(df -Ph -x tmpfs -x devtmpfs -x squashfs -x overlay -x efivarfs 2>/dev/null | awk 'NR > 1 {print $5, $4, $6}')
echo
if [ "$DISK_OVER" -gt 0 ]; then
  echo "  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "  !!  DISK ALERT: $DISK_OVER disk(s) at or above the $THRESHOLD% threshold"
  echo "  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  while read -r mnt pct avail; do
    alert HIGH "disk:$mnt" "DISK ALERT: $mnt is $pct% full (threshold $THRESHOLD%), $avail free"
  done <"$WORK/over"
  echo "  Biggest folders to clean up:"
  du -xsh /var/log /var/backups /var/cache/apt /var/www /tmp /home 2>/dev/null | sort -rh | head -n 5 |
    awk '{printf "    %6s  %s\n", $1, $2}'
  echo
fi

# ---------------------------------------------------------------------
# 6. Other risks (skipped with --disk-only)
# ---------------------------------------------------------------------
if [ "$DISK_ONLY" = "no" ]; then
echo "Other risks (last $MINUTES minute(s) of logs):"

# 6a. Changed system and app files (compared with the baseline)
if [ ! -s "$BASE_FILE" ]; then
  alert LOW no-baseline "no file baseline yet: run sudo ./$SCRIPT_NAME --baseline once"
else
  changed="$(sha256sum --quiet -c "$BASE_FILE" 2>/dev/null | sed 's/: .*//' | tr '\n' ' ')"
  [ -n "$changed" ] && alert HIGH files-changed "watched files changed or deleted since the baseline: $changed(if you changed them, run --baseline again)"
  new="$(watched_files | while read -r f; do [ -f "$f" ] && ! grep -qF "  $f" "$BASE_FILE" && printf '%s ' "$f"; done)"
  [ -n "$new" ] && alert HIGH files-new "new watched files since the baseline: $new"
fi

# 6b. SSH password guessing and root logins (journal, or /var/log/auth.log)
SINCE="$(date -d "-$MINUTES minutes" '+%F %T')"
{ journalctl -q --no-pager -o short-iso --since "$SINCE" -t sshd -t sshd-session 2>/dev/null
  awk -v s="$SINCE" '{t = substr($1, 1, 19); sub("T", " ", t); if (t >= s) print}' /var/log/auth.log 2>/dev/null
} | sort -u >"$WORK/auth"
fails="$(grep -cE 'Failed password|Invalid user' "$WORK/auth")"
if [ "$fails" -ge "$SSH_FAIL_LIMIT" ]; then
  ip="$(grep -E 'Failed password|Invalid user' "$WORK/auth" | grep -oE 'from [0-9a-fA-F.:]+' | sort | uniq -c | sort -rn | head -n 1 | awk '{print $3, "(" $1 " tries)"}')"
  alert HIGH ssh-bruteforce "$fails failed SSH logins in $MINUTES min (limit $SSH_FAIL_LIMIT), most from $ip: someone may be guessing passwords"
fi
grep -qE 'Accepted [a-z]+ for root ' "$WORK/auth" &&
  alert HIGH ssh-root "someone logged in over SSH as root: $(grep -E 'Accepted [a-z]+ for root ' "$WORK/auth" | tail -n 1 | grep -oE 'from [^ ]+')"
if command -v sshd >/dev/null && sshd -T 2>/dev/null | grep -qi '^permitrootlogin yes'; then
  alert MEDIUM ssh-rootallowed "SSH allows root to log in with a password (PermitRootLogin yes in /etc/ssh/sshd_config)"
fi

# 6c. The website: login abuse, attack probes, floods, server errors
if [ -f "$NGINX_ACCESS_LOG" ]; then
  start="$(date -d "-$MINUTES minutes" '+%Y%m%d%H%M%S')"
  { [ -f "$NGINX_ACCESS_LOG.1" ] && cat "$NGINX_ACCESS_LOG.1"; cat "$NGINX_ACCESS_LOG"; } | awk -v start="$start" '
    BEGIN { split("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec", m, " ")
            for (i = 1; i <= 12; i++) mon[m[i]] = sprintf("%02d", i) }
    { split(substr($4, 2), d, /[\/:]/); if ((d[3] mon[d[2]] d[1] d[4] d[5] d[6]) >= start) print }' >"$WORK/web"
  total="$(wc -l <"$WORK/web")"
  # Refused logins (wrong password, throttled) on the app's sign-in routes
  logins="$(awk '$6 ~ /POST/ && $7 ~ /^\/api\/auth\/(cust_login|emp_login|recover_credentials|reset_credentials)/ && $9 ~ /^(401|403|422|423|429)$/' "$WORK/web")"
  n="$(grep -c . <<<"$logins")"
  if [ "$n" -ge "$LOGIN_FAIL_LIMIT" ]; then
    ip="$(awk '{print $1}' <<<"$logins" | sort | uniq -c | sort -rn | head -n 1 | awk '{print $2, "(" $1 ")"}')"
    alert HIGH login-abuse "$n refused sign-ins on /api/auth in $MINUTES min (limit $LOGIN_FAIL_LIMIT), most from $ip: password guessing on the store"
  fi
  # Requests for files an attacker looks for (secrets, other apps' admin pages)
  probes="$(awk '{print $1, $7}' "$WORK/web" | grep -iE ' [^ ]*(\.env|\.git/|wp-login|wp-admin|xmlrpc|phpmyadmin|\.\./|\.\.%2f|%2e%2e|/etc/passwd|\.sql|\.bak|/vendor/phpunit|/cgi-bin/)')"
  n="$(grep -c . <<<"$probes")"
  if [ "$n" -ge "$PROBE_LIMIT" ]; then
    ip="$(awk '{print $1}' <<<"$probes" | sort | uniq -c | sort -rn | head -n 1 | awk '{print $2, "(" $1 ")"}')"
    alert MEDIUM web-probe "$n requests for attack paths such as /.env or /wp-login in $MINUTES min (limit $PROBE_LIMIT), most from $ip: the site is being scanned"
  fi
  # One address sending far more requests than a person could
  top="$(awk '{print $1}' "$WORK/web" | sort | uniq -c | sort -rn | head -n 1)"
  if [ -n "$top" ] && [ "$(awk '{print $1}' <<<"$top")" -ge "$FLOOD_LIMIT" ]; then
    alert MEDIUM web-flood "$(awk '{print $2}' <<<"$top") sent $(awk '{print $1}' <<<"$top") requests in $MINUTES min (limit $FLOOD_LIMIT): possible flood or scraper"
  fi
  # Many server errors: the app is failing for visitors
  e5="$(awk '$9 ~ /^5/' "$WORK/web" | wc -l)"
  if [ "$e5" -ge 10 ] && [ $((e5 * 100 / (total > 0 ? total : 1))) -ge 5 ]; then
    alert MEDIUM web-5xx "$e5 of $total requests failed with HTTP 5xx in $MINUTES min: check sudo ./cart-ni-isko-logsummary.sh"
  fi
else
  alert LOW no-accesslog "$NGINX_ACCESS_LOG not found, website traffic not checked (set NGINX_ACCESS_LOG in $CONF)"
fi

# 6d. Services and the site itself
for u in $SERVICES; do
  systemctl is-active --quiet "$u" 2>/dev/null || alert HIGH "down-$u" "service $u is not running: the store may be down (sudo systemctl status $u)"
done
code="$(curl -s -o /dev/null -m 20 -w '%{http_code}' "$HEALTH_BASE_URL$API_CHECK_PATH")"
[ "$code" = "200" ] || alert HIGH api-down "the API answers HTTP $code instead of 200: customers cannot shop"
code="$(curl -s -o /dev/null -m 10 -w '%{http_code}' "$HEALTH_BASE_URL/.env")"
[ "$code" = "200" ] && alert HIGH env-exposed "/.env can be downloaded from the website: the database password is public"

# 6e. Memory (the disks were checked in section 5)
mem="$(free | awk '/^Mem:/ {printf "%d", ($2 - $7) * 100 / $2}')"
[ "$mem" -ge "$MEM_FAIL_PCT" ] && alert MEDIUM memory "memory is $mem% used (limit $MEM_FAIL_PCT%): PHP may be killed"

# 6f. Backups (Scripts 2 and 3)
newest="$(ls -1t "$BACKUP_DIR"/cart-ni-isko-backup-*.tar.gz 2>/dev/null | head -n 1)"
if [ -z "$newest" ]; then
  alert MEDIUM backup-none "there is no backup in $BACKUP_DIR: lost data could not be restored"
else
  age=$(( ($(date +%s) - $(stat -c %Y "$newest")) / 3600 ))
  [ "$age" -ge "$BACKUP_MAX_AGE_H" ] && alert MEDIUM backup-old "the newest backup is $age hours old (limit $BACKUP_MAX_AGE_H)"
fi
grep -E ' BACKUP (OK|FAIL) ' "$LOG_DIR/backup.log" 2>/dev/null | tail -n 1 | grep -q 'BACKUP FAIL' &&
  alert HIGH backup-failed "the last backup failed verification: see $LOG_DIR/backup.log"

# 6g. Unsafe permissions and settings
perm() { stat -c '%U:%G %a' "$1" 2>/dev/null; }
ENV_FILE="$APP_DIR/backend/.env"
if [ -f "$ENV_FILE" ]; then
  p="$(perm "$ENV_FILE")"
  [ "$p" = "root:$WEB_GROUP 640" ] || alert HIGH env-perms "$ENV_FILE is $p, expected root:$WEB_GROUP 640: the database password may be readable"
  grep -qiE '^APP_DEBUG=("|)true' "$ENV_FILE" &&
    alert HIGH app-debug "APP_DEBUG=true in $ENV_FILE: error pages show code and settings to visitors"
else
  alert HIGH env-missing "$ENV_FILE is missing: the app cannot reach the database (restore with Script 3)"
fi
if [ -f "$DB_CONF" ]; then
  p="$(perm "$DB_CONF")"
  { [ "${p%%:*}" = "root" ] && [ "${p##* }" = "600" ]; } || alert HIGH dbconf-perms "$DB_CONF is $p, expected root mode 600: the database password may be readable"
fi
p="$(perm "$BACKUP_DIR")"
[ -z "$p" ] || [ "${p##* }" = "700" ] || alert HIGH backup-perms "$BACKUP_DIR is $p, expected mode 700: backups hold passwords and customer data"
if [ -d "$APP_DIR/backend/app" ] && id "$WEB_USER" >/dev/null 2>&1; then
  if runuser -u "$WEB_USER" -- test -w "$APP_DIR/backend/app"; then
    alert HIGH code-writable "the web server ($WEB_USER) can change the code in $APP_DIR/backend/app: re-run Script 1 with --force"
  fi
fi
ww="$(find "$APP_DIR" /etc/cart-ni-isko -xdev -perm -0002 ! -type l 2>/dev/null | head -n 3 | tr '\n' ' ')"
[ -n "$ww" ] && alert HIGH world-writable "files anyone can change: $ww"

# 6h. Updates
if command -v apt-get >/dev/null; then
  sec="$(apt-get -s -o Debug::NoLocking=1 upgrade 2>/dev/null | grep '^Inst ' | grep -ci security)"
  [ "$sec" -gt 0 ] && alert LOW updates "$sec security update(s) waiting: sudo apt update && sudo apt upgrade"
fi
[ -f /var/run/reboot-required ] && alert LOW reboot "a reboot is needed to finish installing updates"
fi   # end of the other risk checks

# ---------------------------------------------------------------------
# 7. Result and notifications
# ---------------------------------------------------------------------
echo
if [ $((HIGH + MEDIUM + LOW)) -eq 0 ]; then
  echo "  No alerts."
fi
RESULT="$HIGH HIGH, $MEDIUM MEDIUM, $LOW LOW"
echo "$(date '+%F %T') CHECK threshold=$THRESHOLD disks_over=$DISK_OVER high=$HIGH medium=$MEDIUM low=$LOW" >>"$LOG_DIR/alerts.log"
if [ "$NOTIFY" = "yes" ] && [ -s "$WORK/notify" ]; then
  msg="$(printf 'Cart ni Isko ALERT on %s\n' "$(hostname)"; cat "$WORK/notify")"
  command -v wall >/dev/null && wall <<<"$msg" 2>/dev/null
  if [ -n "$ALERT_EMAIL" ] && command -v mail >/dev/null; then
    mail -s "Cart ni Isko alert ($HIGH HIGH)" "$ALERT_EMAIL" <<<"$msg" &&
      echo "  Sent the HIGH alerts to $ALERT_EMAIL"
  fi
  echo "  Notified: $(grep -c . "$WORK/notify") new HIGH alert(s)"
fi

# ---------------------------------------------------------------------
# 8. Optional: run every 15 minutes with a systemd timer
# ---------------------------------------------------------------------
if [ "$TIMER" = "yes" ]; then
  install -o root -g root -m 750 "$0" /usr/local/sbin/cart-ni-isko-diskalert.sh
  printf '%s\n' '[Unit]' 'Description=Cart ni Isko disk alert and risk check (Script 6)' '' \
    '[Service]' 'Type=oneshot' 'ExecStart=/usr/local/sbin/cart-ni-isko-diskalert.sh --notify --minutes 15' \
    'SuccessExitStatus=3 4' >/etc/systemd/system/cart-ni-isko-diskalert.service
  printf '%s\n' '[Unit]' 'Description=Run the Cart ni Isko disk alert every 15 minutes' '' \
    '[Timer]' 'OnCalendar=*:0/15' 'Persistent=true' '' '[Install]' 'WantedBy=timers.target' \
    >/etc/systemd/system/cart-ni-isko-diskalert.timer
  chmod 644 /etc/systemd/system/cart-ni-isko-diskalert.{service,timer}
  systemctl daemon-reload && systemctl enable --now cart-ni-isko-diskalert.timer >/dev/null 2>&1 ||
    die "could not enable cart-ni-isko-diskalert.timer: systemctl status cart-ni-isko-diskalert.timer"
  # This script just wrote these two watched files itself, so add them to the
  # trusted baseline; otherwise every later run reports them as HIGH.
  if [ -f "$BASE_FILE" ]; then
    for f in /etc/systemd/system/cart-ni-isko-diskalert.service /etc/systemd/system/cart-ni-isko-diskalert.timer; do
      grep -vF "  $f" "$BASE_FILE" >"$WORK/base" ; sha256sum "$f" >>"$WORK/base" ; cat "$WORK/base" >"$BASE_FILE"
    done
  fi
  echo "==> Disk alert timer installed (every 15 minutes, with --notify, threshold $THRESHOLD%)"
fi

if [ "$DISK_OVER" -gt 0 ]; then
  echo "DISK ALERT: $DISK_OVER disk(s) at or above $THRESHOLD%. Free space now. ($RESULT)"
  exit 3
fi
if [ $((HIGH + MEDIUM)) -gt 0 ]; then
  echo "RISK: disks below $THRESHOLD%, but $RESULT. Act on the HIGH alerts first."
  exit 4
fi
echo "OK: every disk below $THRESHOLD%; $RESULT."
exit 0
