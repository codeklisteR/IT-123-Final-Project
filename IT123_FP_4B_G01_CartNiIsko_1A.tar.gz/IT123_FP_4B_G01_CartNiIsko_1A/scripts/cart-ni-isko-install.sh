#!/bin/bash
# =====================================================================
# cart-ni-isko-install.sh - Script 1: Installation
#
# Purpose : Installs the platform (Nginx, PHP-FPM, Composer, Node.js 22),
#           deploys the Laravel API and builds the React/Vite storefront,
#           connects to the existing Supabase PostgreSQL database (no
#           migrations: the live schema is maintained separately), sets
#           least-privilege ownership and permissions, sets up Nginx and
#           the Laravel scheduler service (systemd), optionally HTTPS with
#           certbot, then checks that the storefront, the API, the database
#           and the scheduler heartbeat all answer.
# Authors : Group G01
#           Brucelo, Alyssa Mae B.; Ebuenga, Kristel Ann B.;
#           Fenis, Austin B.; Marfil, John Marvin G.
# Usage   : sudo ./cart-ni-isko-install.sh [--help] [--offline] [--force]
# Needs   : a clean Ubuntu Server 24.04 or 26.04, the repository cloned to
#           APP_SRC, and APP_SRC/backend/.env filled in (mode 600).
# AI note : Drafted with help from Claude (Anthropic AI). Every line was
#           reviewed, tested and can be explained by the group (Section 5.6).
# =====================================================================

set -o pipefail                     # a pipe fails if any command in it fails

CONF_FILE="${CARTNIISKO_CONF:-/etc/cart-ni-isko/cart-ni-isko.conf}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
OFFLINE=0
FORCE=0

# ---------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------
usage() {
    cat <<EOF
Usage: sudo $(basename "$0") [--help] [--offline] [--force]

Installs Cart ni Isko (Laravel API + React storefront) on this server.
The database is the existing remote Supabase PostgreSQL; it is only
connected to and checked, never migrated or changed.

Before running:
  1. git clone -b dev https://github.com/capstone-cart-ni-isko/Cart-Ni-Isko.git APP_SRC
  2. cp APP_SRC/backend/.env.example APP_SRC/backend/.env  and fill in the
     Supabase DB_* values (keep DB_SSLMODE=require)
  3. edit cart-ni-isko.conf (APP_URL = your VM's address)

Options:
  --help      show this help and exit
  --offline   no internet: do not run 'apt-get update'; install packages,
              Composer and npm dependencies from the local caches only
  --force     replace an existing deployment (the old one is moved to
              BACKUP_DIR first; uploaded files in backend/storage/app are kept)

Settings: $CONF_FILE (owner root, mode 600).
If it is missing, ./cart-ni-isko.conf next to this script is installed there.

Examples:
  sudo ./$(basename "$0")
  sudo ./$(basename "$0") --force

Exit status: 0 installed and working, 1 error, 2 bad usage,
             3 installed but a final check failed
EOF
}

die()  { echo "ERROR: $*" >&2; exit 1; }
info() { echo "==> $*"; }

load_config() {
    [ -f "$CONF_FILE" ] || die "configuration file $CONF_FILE not found."
    local owner perms
    owner=$(stat -c '%U' "$CONF_FILE")
    perms=$(stat -c '%a' "$CONF_FILE")
    if [ "$owner" != "root" ] || [ "$perms" != "600" ]; then
        die "$CONF_FILE must be owner root, mode 600 (now $owner $perms). Fix: sudo chown root:root $CONF_FILE && sudo chmod 600 $CONF_FILE"
    fi
    # shellcheck source=/dev/null
    . "$CONF_FILE"
}

# set_env FILE KEY VALUE : change KEY=... in a .env file, or add it if missing
set_env() {
    if grep -qE "^$2=" "$1"; then
        sed -i "s|^$2=.*|$2=$3|" "$1"
    else
        echo "$2=$3" >> "$1"
    fi
}

# Least privilege: root owns the code; the web group can only read it;
# only Laravel's storage/ and bootstrap/cache/ are writable by PHP-FPM.
# (Safer than the Dockerfile's chmod -R 777.)
apply_permissions() {
    chown -R root:"$WEB_GROUP" "$APP_DIR"
    find "$APP_DIR" -type d -exec chmod 750 {} +
    find "$APP_DIR" -type f -exec chmod 640 {} +
    local d
    for d in "$BACKEND/storage" "$BACKEND/bootstrap/cache"; do
        chown -R "$WEB_USER":"$WEB_GROUP" "$d"
        find "$d" -type d -exec chmod 770 {} +
        find "$d" -type f -exec chmod 660 {} +
    done
    chown root:"$WEB_GROUP" "$BACKEND/.env"
    chmod 640 "$BACKEND/.env"
}

# ---------------------------------------------------------------------
# 1. Read options
# ---------------------------------------------------------------------
while [ $# -gt 0 ]; do
    case "$1" in
        --help|-h) usage; exit 0 ;;
        --offline) OFFLINE=1 ;;
        --force)   FORCE=1 ;;
        *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
    esac
    shift
done

# ---------------------------------------------------------------------
# 2. Check what we need before doing any work
# ---------------------------------------------------------------------
[ "$(id -u)" -eq 0 ] || die "this script must be run as root (use sudo)."

# Tested on Ubuntu 24.04 (PHP 8.3) and 26.04 (PHP 8.5); PHP_VER in the config must match
grep -qE 'VERSION_ID="(24|26)\.04"' /etc/os-release 2>/dev/null \
    || echo "WARNING: this is not Ubuntu 24.04 or 26.04; package names may differ."

# First run: copy the sample config next to this script into place, then stop
if [ ! -f "$CONF_FILE" ] && [ -f "$SCRIPT_DIR/cart-ni-isko.conf" ]; then
    install -D -o root -g root -m 600 "$SCRIPT_DIR/cart-ni-isko.conf" "$CONF_FILE" \
        && info "Installed settings to $CONF_FILE (mode 600). Check APP_URL there, then run this script again." \
        && exit 0
fi
load_config

for var in APP_NAME APP_SRC APP_DIR APP_URL PHP_VER NODE_MAJOR WEB_USER WEB_GROUP API_CHECK_PATH SCHEDULER_CHECK_PATH BACKUP_DIR REPORT_DIR; do
    [ -n "${!var}" ] || die "$var is empty in $CONF_FILE."
done
[[ "$APP_URL" =~ ^https?://[^/]+$ ]] || die "APP_URL must look like http://192.168.56.10 (no path, no trailing /)."
[[ "$APP_DIR" =~ ^/var/www/[A-Za-z0-9._-]+$ ]] || die "APP_DIR must be a folder directly under /var/www."

BACKEND="$APP_DIR/backend"
FRONTEND="$APP_DIR/frontend"
SRC_ENV="$APP_SRC/backend/.env"

[ -d "$APP_SRC/backend" ] && [ -d "$APP_SRC/frontend" ] \
    || die "$APP_SRC does not look like the Cart-Ni-Isko repository (backend/ and frontend/ missing)."
[ -f "$SRC_ENV" ] || die "$SRC_ENV not found. Run: cp $APP_SRC/backend/.env.example $SRC_ENV  and fill in the Supabase settings."

# The .env holds the database password: it must be readable only by its owner
if [ "$(stat -c '%a' "$SRC_ENV")" != "600" ]; then
    chmod 600 "$SRC_ENV" && info "Set $SRC_ENV to mode 600 (it holds the database password)."
fi
grep -qE '^DB_CONNECTION=pgsql' "$SRC_ENV" || die "DB_CONNECTION=pgsql is missing in $SRC_ENV."
grep -qE '^DB_SSLMODE=require' "$SRC_ENV"  || die "DB_SSLMODE=require is missing in $SRC_ENV (Supabase needs SSL)."
grep -qE '^DB_(HOST|USERNAME|PASSWORD)=.*(YOUR_|<|your-)' "$SRC_ENV" \
    && die "$SRC_ENV still has placeholder DB values. Fill in your real Supabase pooler settings."

# ---------------------------------------------------------------------
# 3. Install the platform
# ---------------------------------------------------------------------
apt_install() {     # apt_install PKG... : install only what is missing
    local missing="" p
    for p in "$@"; do
        dpkg -s "$p" >/dev/null 2>&1 && continue          # already installed
        if ! apt-cache show "$p" >/dev/null 2>&1; then     # not offered by this Ubuntu
            case "$p" in
                *-opcache) echo "NOTE: $p does not exist here (OPcache is built into PHP 8.5+); skipped."; continue ;;
                *) die "package $p is not available on this Ubuntu. Check PHP_VER in $CONF_FILE (apt-cache policy php)." ;;
            esac
        fi
        missing="$missing $p"
    done
    [ -z "$missing" ] && return 0
    info "Installing:$missing"
    if [ "$OFFLINE" -eq 1 ]; then
        # shellcheck disable=SC2086
        DEBIAN_FRONTEND=noninteractive apt-get -o Dpkg::Use-Pty=0 install -y --no-download $missing \
            || die "offline install failed. While online, run: sudo apt-get install --download-only$missing"
    else
        # shellcheck disable=SC2086
        DEBIAN_FRONTEND=noninteractive apt-get -o Dpkg::Use-Pty=0 install -y $missing || die "installing$missing failed."
    fi
}

if [ "$OFFLINE" -eq 0 ]; then
    info "Updating the package lists"
    apt-get update -q || die "apt-get update failed (no internet? use --offline)."
fi

P="php$PHP_VER"
apt_install ca-certificates curl gnupg git unzip rsync nginx postgresql-client \
    "$P-fpm" "$P-cli" "$P-pgsql" "$P-curl" "$P-mbstring" "$P-xml" "$P-gd" \
    "$P-zip" "$P-bcmath" "$P-intl" "$P-opcache" composer
[ "$ENABLE_HTTPS" = "yes" ] && apt_install certbot python3-certbot-nginx

# Ubuntu 24.04's own nodejs is too old for Vite, so use NodeSource's Node 22.
# Vite 8 needs Node >= 22.12: turn "v22.12.0" into 22012 and compare
node_ver=$(node -v 2>/dev/null | sed -E 's/^v([0-9]+)\.([0-9]+).*/\1 \2/' | awk '{printf "%d%03d", $1, $2}')
if [ "${node_ver:-0}" -lt "${NODE_MAJOR}012" ]; then
    if [ ! -f /etc/apt/sources.list.d/nodesource.list ]; then
        [ "$OFFLINE" -eq 0 ] || die "Node.js $NODE_MAJOR is not installed and there is no internet to add its repository."
        info "Adding the NodeSource repository for Node.js $NODE_MAJOR"
        install -d -m 755 /etc/apt/keyrings
        curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key \
            | gpg --dearmor --yes -o /etc/apt/keyrings/nodesource.gpg \
            || die "could not download the NodeSource signing key."
        echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_$NODE_MAJOR.x nodistro main" \
            > /etc/apt/sources.list.d/nodesource.list
        apt-get update -q || die "apt-get update failed after adding NodeSource."
    fi
    apt_install nodejs
    node_ver=$(node -v | sed -E 's/^v([0-9]+)\.([0-9]+).*/\1 \2/' | awk '{printf "%d%03d", $1, $2}')
    [ "$node_ver" -ge "${NODE_MAJOR}012" ] || die "Node.js $(node -v) is too old; Vite 8 needs $NODE_MAJOR.12 or newer (run: sudo apt-get install --only-upgrade nodejs)."
fi
info "Using PHP $(php -r 'echo PHP_VERSION;'), Composer $(COMPOSER_ALLOW_SUPERUSER=1 composer --version --no-interaction 2>/dev/null | awk '{print $3}'), Node $(node -v)"

[ -n "$TIMEZONE" ] && timedatectl set-timezone "$TIMEZONE" 2>/dev/null && info "Time zone set to $TIMEZONE"

# ---------------------------------------------------------------------
# 4. Copy the application's files
# ---------------------------------------------------------------------
STAMP=$(date +%Y%m%d-%H%M%S)
install -d -o root -g root -m 700 "$BACKUP_DIR"
install -d -o root -g adm  -m 750 "$REPORT_DIR"

OLD=""
if [ -d "$APP_DIR" ] && [ -n "$(ls -A "$APP_DIR" 2>/dev/null)" ]; then
    [ "$FORCE" -eq 1 ] || die "$APP_DIR already exists. Use --force to replace it."
    OLD="$BACKUP_DIR/old-deploy-$STAMP"
    mv "$APP_DIR" "$OLD" && info "Moved the old deployment to $OLD"
fi

info "Copying $APP_SRC to $APP_DIR"
mkdir -p "$APP_DIR"
rsync -a --exclude '.git' --exclude 'node_modules' --exclude 'backend/vendor' \
      --exclude 'backend/.env' --exclude 'frontend/dist' --exclude 'frontend/.env*' \
      "$APP_SRC"/ "$APP_DIR"/ || die "copying the application failed."

# Keep files users uploaded (product images etc.) when reinstalling
if [ -n "$OLD" ] && [ -d "$OLD/backend/storage/app" ]; then
    cp -a "$OLD/backend/storage/app/." "$BACKEND/storage/app/" && info "Kept uploaded files from the old deployment."
fi
mkdir -p "$BACKEND"/storage/{app/public,framework/cache,framework/sessions,framework/views,logs} "$BACKEND/bootstrap/cache"

# ---------------------------------------------------------------------
# 5. Back end: Laravel API
# ---------------------------------------------------------------------
cd "$BACKEND" || die "cannot enter $BACKEND."

# Give the app an encryption key once, and save it in the source .env so a
# reinstall keeps the same key (a new key would log everyone out).
if ! grep -qE '^APP_KEY=base64:.+' "$SRC_ENV"; then
    key="base64:$(php -r 'echo base64_encode(random_bytes(32));')"
    set_env "$SRC_ENV" APP_KEY "$key" && info "Generated APP_KEY in $SRC_ENV"
fi

info "Writing the production .env"
cp "$SRC_ENV" "$BACKEND/.env"

# The toolkit's own copy of the database settings. Scripts 2, 3 and 5 read
# the password from this file, which only root can read (Section 5.1), and
# never from a script. It is only read by them, never run.
DB_CONF="$(dirname "$CONF_FILE")/db.conf"
( umask 077; grep -E '^DB_(HOST|PORT|DATABASE|USERNAME|PASSWORD|SSLMODE)=' "$SRC_ENV" > "$DB_CONF" ) \
    && chown root:root "$DB_CONF" && chmod 600 "$DB_CONF" \
    || die "could not write $DB_CONF."
info "Wrote the toolkit's database settings to $DB_CONF (root, mode 600)"
set_env "$BACKEND/.env" APP_ENV production
set_env "$BACKEND/.env" APP_DEBUG false          # never show error details to users
set_env "$BACKEND/.env" APP_URL "$APP_URL"
set_env "$BACKEND/.env" FRONTEND_URL "$APP_URL"
# Browsers reach the API from the same address as the storefront
set_env "$BACKEND/.env" CORS_ALLOWED_ORIGINS "$APP_URL"
# Same drivers as the hosted deployment (render.yaml)
set_env "$BACKEND/.env" CACHE_STORE file
set_env "$BACKEND/.env" SESSION_DRIVER file
set_env "$BACKEND/.env" QUEUE_CONNECTION sync
# If the app broadcasts through Reverb but Reverb is not set up here, log instead
if grep -qE '^BROADCAST_CONNECTION=reverb' "$BACKEND/.env" && [ "$ENABLE_REVERB" != "yes" ]; then
    set_env "$BACKEND/.env" BROADCAST_CONNECTION log
    info "Reverb is off (ENABLE_REVERB=no): broadcasting set to 'log'."
fi

info "Installing PHP dependencies with Composer"
export COMPOSER_ALLOW_SUPERUSER=1
# COMPOSER_FLAGS (config, optional) e.g. "--ignore-platform-req=php" if a locked
# package has not yet declared support for this PHP version
# shellcheck disable=SC2086
if ! composer install --no-dev --optimize-autoloader --no-interaction --no-progress $COMPOSER_FLAGS; then
    [ "$OFFLINE" -eq 1 ] && die "composer install failed offline: run the script once while online so Composer's cache is filled."
    die "composer install failed. If it says a package 'requires php' below $(php -r 'echo PHP_VERSION;'), set COMPOSER_FLAGS=\"--ignore-platform-req=php\" in $CONF_FILE."
fi

# NO 'php artisan migrate': the live Supabase schema is maintained by hand
# (backend/schema.sql) and does not match the migrations table, so
# migrating could fail or change live data. See backend/docker-start.sh.

info "Caching Laravel configuration, routes and events"
php artisan config:clear >/dev/null
php artisan config:cache && php artisan route:cache && php artisan event:cache \
    || die "Laravel caching failed; run 'php artisan config:cache' in $BACKEND to see why."
[ -L public/storage ] || php artisan storage:link || die "php artisan storage:link failed."

# ---------------------------------------------------------------------
# 6. Front end: React/Vite storefront
# ---------------------------------------------------------------------
cd "$FRONTEND" || die "cannot enter $FRONTEND."
info "Writing frontend/.env.production"
{
    echo "VITE_API_BASE_URL=$VITE_API_BASE_URL"
    [ -n "$VITE_SUPABASE_URL" ]      && echo "VITE_SUPABASE_URL=$VITE_SUPABASE_URL"
    [ -n "$VITE_SUPABASE_ANON_KEY" ] && echo "VITE_SUPABASE_ANON_KEY=$VITE_SUPABASE_ANON_KEY"
} > .env.production
grep -qi 'service_role' .env.production && die "a service-role key must never go into the frontend."

info "Building the storefront (npm ci && npm run build)"
if [ "$OFFLINE" -eq 1 ]; then npm_flags="--offline"; else npm_flags="--no-audit --no-fund"; fi
# shellcheck disable=SC2086
npm ci $npm_flags && npm run build || die "the frontend build failed."
[ -f dist/index.html ] || die "build finished but frontend/dist/index.html is missing."
rm -rf "$FRONTEND/node_modules"        # only needed for building; saves disk space

# ---------------------------------------------------------------------
# 7. Ownership and permissions
# ---------------------------------------------------------------------
info "Setting ownership and permissions"
apply_permissions

# ---------------------------------------------------------------------
# 8. PHP-FPM, Nginx and the scheduler service
# ---------------------------------------------------------------------
FPM_SOCK="/run/php/php$PHP_VER-fpm.sock"

# OPcache settings taken from the repository's Dockerfile
cat > "/etc/php/$PHP_VER/fpm/conf.d/99-$APP_NAME.ini" <<EOF
; Cart ni Isko - written by $(basename "$0")
opcache.enable=1
opcache.memory_consumption=192
opcache.max_accelerated_files=20000
opcache.validate_timestamps=0
realpath_cache_size=4096K
realpath_cache_ttl=600
expose_php=Off
upload_max_filesize=20M
post_max_size=20M
EOF

SITE="/etc/nginx/sites-available/$APP_NAME"
info "Writing the Nginx site $SITE"
cat > "$SITE" <<EOF
# Cart ni Isko - written by $(basename "$0")
server {
    listen 80 default_server;
    server_name ${DOMAIN:-_};
    client_max_body_size 20M;
    server_tokens off;

    access_log /var/log/nginx/${APP_NAME}_access.log;
    error_log  /var/log/nginx/${APP_NAME}_error.log;

    # React storefront (built files)
    root $FRONTEND/dist;
    index index.html;

    # Never serve hidden files such as .env or .git
    location ~ /\. { deny all; }

    # Laravel API: every /api, /sanctum and /broadcasting request goes to
    # backend/public/index.php through PHP-FPM
    location ~ ^/(api|sanctum|broadcasting)(/|\$) {
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $BACKEND/public/index.php;
        fastcgi_param SCRIPT_NAME /index.php;
        fastcgi_pass unix:$FPM_SOCK;
        fastcgi_read_timeout 60s;
    }

    # Product images and other public files (php artisan storage:link)
    location /storage/ {
        alias $BACKEND/public/storage/;
        expires 7d;
    }
EOF
if [ "$ENABLE_REVERB" = "yes" ]; then
    cat >> "$SITE" <<'EOF'

    # Laravel Reverb WebSocket (live stock, orders and notification badges)
    location ~ ^/(app|apps)/ {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_read_timeout 3600s;
    }
EOF
fi
cat >> "$SITE" <<'EOF'

    # Single-page app: unknown paths return index.html so React Router works
    location / {
        try_files $uri $uri/ /index.html;
    }
}
EOF
chmod 644 "$SITE"
ln -sf "$SITE" "/etc/nginx/sites-enabled/$APP_NAME"
rm -f /etc/nginx/sites-enabled/default
nginx -t 2>/dev/null || die "Nginx configuration test failed; run 'sudo nginx -t' to see why."
systemctl reload nginx 2>/dev/null

# HTTPS (PayMongo return URLs and webhooks need https://). Needs a real domain
# that points to this server and internet access; a lab VM with only an IP
# address cannot get a certificate, so this is off by default.
if [ "$ENABLE_HTTPS" = "yes" ]; then
    [ -n "$DOMAIN" ] && [ -n "$CERTBOT_EMAIL" ] || die "ENABLE_HTTPS=yes needs DOMAIN and CERTBOT_EMAIL in $CONF_FILE."
    [[ "$APP_URL" == https://* ]] || die "with HTTPS on, APP_URL must start with https://"
    info "Requesting a Let's Encrypt certificate for $DOMAIN"
    certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "$CERTBOT_EMAIL" --redirect \
        || die "certbot failed. Check that $DOMAIN points to this server and port 80 is open."
fi

# make_service NAME DESCRIPTION ARTISAN-COMMAND : a systemd unit that runs as www-data
make_service() {
    cat > "/etc/systemd/system/$1.service" <<EOF
[Unit]
Description=$2
After=network-online.target php$PHP_VER-fpm.service
Wants=network-online.target

[Service]
User=$WEB_USER
Group=$WEB_GROUP
WorkingDirectory=$BACKEND
ExecStart=/usr/bin/php artisan $3
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
    chmod 644 "/etc/systemd/system/$1.service"
}

info "Creating the Laravel scheduler service"
make_service "$APP_NAME-scheduler" "Cart ni Isko - Laravel scheduler (schedule:work)" "schedule:work"
units="php$PHP_VER-fpm nginx $APP_NAME-scheduler"
if [ "$ENABLE_REVERB" = "yes" ]; then
    make_service "$APP_NAME-reverb" "Cart ni Isko - Laravel Reverb WebSocket server" "reverb:start --host=127.0.0.1 --port=8080"
    units="$units $APP_NAME-reverb"
fi

systemctl daemon-reload
for u in $units; do
    systemctl enable "$u" >/dev/null 2>&1 && systemctl restart "$u" \
        || die "service $u did not start. See: sudo journalctl -u $u -n 30"
    info "Service $u is $(systemctl is-active "$u")"
done

# ---------------------------------------------------------------------
# 9. Check that the application really works
# ---------------------------------------------------------------------
fail=0

# Where the checks connect: plain HTTP on this machine, or the HTTPS site
# (curl --resolve sends DOMAIN to 127.0.0.1 so no DNS is needed).
if [ "$ENABLE_HTTPS" = "yes" ]; then
    BASE="https://$DOMAIN"; CURL_OPTS=(--resolve "$DOMAIN:443:127.0.0.1")
else
    BASE="http://127.0.0.1"; CURL_OPTS=()
fi

# 9a. Database: boot Laravel as www-data (also proves PHP-FPM's user can read .env)
info "Checking the Supabase database connection"
db_out=$(cd "$BACKEND" && runuser -u "$WEB_USER" -- php -r '
    require "vendor/autoload.php";
    $app = require "bootstrap/app.php";
    $app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
    echo Illuminate\Support\Facades\DB::selectOne("select version() as v")->v;' 2>&1)
if [ $? -eq 0 ]; then
    echo "  [OK]   database answers: ${db_out:0:60}"
else
    echo "  [FAIL] cannot reach the database: $(echo "$db_out" | grep -m1 -iE 'SQLSTATE|error' | cut -c1-150)"
    fail=1
fi

# 9b. Storefront and API through Nginx
check_url() {   # check_url LABEL URL : retry a few times, OK on HTTP 2xx
    local code try
    for try in 1 2 3; do
        code=$(curl "${CURL_OPTS[@]}" -s -o /dev/null -w '%{http_code}' --max-time 30 "$2")
        case "$code" in 2??) echo "  [OK]   $1 answers (HTTP $code)"; return 0 ;; esac
        sleep 3
    done
    echo "  [FAIL] $1 answered HTTP $code"
    return 1
}
info "Checking the web server"
check_url "storefront $APP_URL/" "$BASE/" || fail=1
curl "${CURL_OPTS[@]}" -s --max-time 10 "$BASE/" | grep -q 'id="root"' \
    && echo "  [OK]   storefront page is the React app" || { echo "  [FAIL] storefront page is not the React app"; fail=1; }
check_url "API $API_CHECK_PATH" "$BASE$API_CHECK_PATH" || fail=1

# The scheduler writes a heartbeat; /api/health/scheduler returns 503 until it
# has run, so allow up to about 90 seconds after the service starts.
info "Waiting for the scheduler heartbeat (up to 90s)"
for try in $(seq 1 18); do
    code=$(curl "${CURL_OPTS[@]}" -s -o /dev/null -w '%{http_code}' --max-time 10 "$BASE$SCHEDULER_CHECK_PATH")
    [ "$code" = "200" ] && break
    sleep 5
done
if [ "$code" = "200" ]; then
    echo "  [OK]   scheduler is alive ($SCHEDULER_CHECK_PATH = HTTP 200)"
else
    echo "  [FAIL] $SCHEDULER_CHECK_PATH answered HTTP $code. See: sudo journalctl -u $APP_NAME-scheduler -n 30"
    fail=1
fi
curl "${CURL_OPTS[@]}" -s -o /dev/null -w '%{http_code}' --max-time 5 "$BASE/.env" | grep -q '^40[34]$' \
    && echo "  [OK]   hidden files such as .env are blocked" || { echo "  [FAIL] /.env is reachable"; fail=1; }

if [ "$fail" -eq 0 ]; then
    echo "SUCCESS: Cart ni Isko is installed. Open $APP_URL in a browser."
    exit 0
else
    echo "FAILURE: installed, but a check failed. Look at:" >&2
    echo "  sudo tail -n 30 /var/log/nginx/${APP_NAME}_error.log" >&2
    echo "  sudo tail -n 30 $BACKEND/storage/logs/laravel.log" >&2
    exit 3
fi
