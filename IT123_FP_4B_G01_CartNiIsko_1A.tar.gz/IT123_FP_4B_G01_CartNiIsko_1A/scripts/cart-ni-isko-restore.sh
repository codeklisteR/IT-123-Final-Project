#!/bin/bash
# =====================================================================
# cart-ni-isko-restore.sh - Script 3: Restore
#
# Purpose : Puts Cart ni Isko back to the state saved in one backup archive
#           made by Script 2 (cart-ni-isko-backup.sh). It first VERIFIES the
#           archive, then saves the CURRENT state as an undo archive, then
#           restores the database tables (in one transaction: all or nothing),
#           the application files, the uploaded files and, if missing,
#           backend/.env. It ends by CONFIRMING that the restored data matches
#           the backup (row count of every table, SHA-256 of every file) and
#           that the API answers again.
# Authors : Group G01
#           Brucelo, Alyssa Mae B.; Ebuenga, Kristel Ann B.;
#           Fenis, Austin B.; Marfil, John Marvin G.
# Usage   : sudo ./cart-ni-isko-restore.sh FILE | --latest [--db-only | --files-only]
#           [--with-env] [--yes] [--list] [--help]
# Needs   : Script 1 already run; a backup archive made by Script 2; the
#           database settings in /etc/cart-ni-isko/db.conf (mode 600).
# AI note : Drafted with help from Claude (Anthropic AI). Every line was
#           reviewed, tested and can be explained by the group (Section 5.6).
# =====================================================================

set -o pipefail          # a pipe fails if ANY command in it fails
umask 077                # files this script creates are readable by root only

SCRIPT_NAME="$(basename "$0")"
CONF="${CARTNIISKO_CONF:-/etc/cart-ni-isko/cart-ni-isko.conf}"   # same variable as Script 1
STAMP="$(date +%Y-%m-%d_%H%M%S)"
WORK=""                  # temporary folder, removed by cleanup()
FAILS=0                  # number of failed checks
WARNS=0                  # number of warnings

usage() {
  cat <<EOF
Usage: sudo ./$SCRIPT_NAME FILE | --latest [OPTION]...

Restores Cart ni Isko from a backup archive made by Script 2. The archive is
verified first, and the current state is saved as an undo archive
(cart-ni-isko-prerestore-<date>.tar.gz) before anything is changed.

  FILE              the backup archive to restore (see --list)
  --latest          use the newest backup in BACKUP_DIR
  --db-only         restore only the database tables
  --files-only      restore only the uploaded files (and .env if missing)
  --with-env        also replace backend/.env with the one in the backup
  --yes             do not ask for confirmation (for scripts)
  --list            list the backups and undo archives, then exit
  -h, --help        show this help and exit

Examples:
  sudo ./$SCRIPT_NAME --latest
  sudo ./$SCRIPT_NAME /var/backups/cart-ni-isko/cart-ni-isko-backup-2026-11-25_020000.tar.gz
  sudo ./$SCRIPT_NAME /var/backups/cart-ni-isko/cart-ni-isko-prerestore-2026-11-25_101500.tar.gz  (undo)

Exit status: 0 restored and checked, 1 error, 2 bad option,
             3 restored but a final check failed.
EOF
}

# ---------------------------------------------------------------------
# Message helpers
# ---------------------------------------------------------------------
say()  { echo "==> $*"; }
ok()   { echo "  [OK]   $*"; }
warn() { echo "  [WARN] $*"; WARNS=$((WARNS + 1)); }
bad()  { echo "  [FAIL] $*"; FAILS=$((FAILS + 1)); }
die()  { echo "ERROR: $*" >&2; log_line "ERROR $*"; exit 1; }

log_line() {   # one line per run in the restore log (read by Script 4)
  [ -n "${LOG_DIR:-}" ] && [ -d "$LOG_DIR" ] || return 0
  echo "$(date '+%F %T') $*" >>"$LOG_DIR/restore.log"
}

errline() {    # the most useful line of the last error output
  grep -m1 -iE 'fatal|error' "$WORK/err" || tail -n 1 "$WORK/err"
}

cleanup() {    # runs on every exit: delete the temporary folder
  [ -n "$WORK" ] && [ -d "$WORK" ] && rm -rf -- "$WORK"
}
trap cleanup EXIT
trap 'echo; die "stopped with Ctrl+C (the database is unchanged unless step 7 had finished)"' INT

# ---------------------------------------------------------------------
# Read one value from a Laravel .env file without running it
# ---------------------------------------------------------------------
env_get() {    # env_get KEY FILE  -> prints the value, quotes removed
  local v
  v="$(grep -m1 -E "^$1=" "$2" | cut -d= -f2- | tr -d '\r')"
  case "$v" in
    \"*\") v="${v#\"}"; v="${v%\"}" ;;
    \'*\') v="${v#\'}"; v="${v%\'}" ;;
  esac
  printf '%s' "$v"
}

# ---------------------------------------------------------------------
# Load the shared toolkit config (same rules as Scripts 1 and 2)
# ---------------------------------------------------------------------
load_config() {
  [ -f "$CONF" ] || die "$CONF not found. Run Script 1 (cart-ni-isko-install.sh) first."
  [ "$(stat -c '%U:%a' "$CONF")" = "root:600" ] ||
    die "$CONF must be owner root, mode 600: sudo chown root:root $CONF && sudo chmod 600 $CONF"
  # shellcheck source=/dev/null
  . "$CONF"
  APP_DIR="${APP_DIR:-/var/www/cart-ni-isko}"
  BACKUP_DIR="${BACKUP_DIR:-/var/backups/cart-ni-isko}"
  PG_BIN="${PG_BIN:-/usr/lib/postgresql/17/bin}"
  APP_NAME="${APP_NAME:-cart-ni-isko}"
  WEB_USER="${WEB_USER:-www-data}"; WEB_GROUP="${WEB_GROUP:-www-data}"
  LOG_DIR="${LOG_DIR:-${REPORT_DIR:-/var/log/cart-ni-isko-toolkit}}"   # Script 1 creates REPORT_DIR
  PHP_VER="${PHP_VER:-8.5}"
  RESTORE_UNDO_KEEP="${RESTORE_UNDO_KEEP:-3}"
  RESTORE_CHECK_URL="${RESTORE_CHECK_URL:-http://127.0.0.1${API_CHECK_PATH:-/api/products/filter}}"
  DB_CONF="${DB_CONF:-$(dirname "$CONF")/db.conf}"   # written by Script 1
}

# ---------------------------------------------------------------------
# Read the database settings from the toolkit's own owner-only file
# ---------------------------------------------------------------------
# Section 5.1: passwords are never written in a script; they are read from a
# file only its owner (root) can read. db.conf is never run (sourced), only read.
load_db() {
  [ -f "$DB_CONF" ] || die "$DB_CONF not found. Script 1 writes it; for an older install create it once:
  sudo sh -c 'umask 077; grep -E \"^DB_(HOST|PORT|DATABASE|USERNAME|PASSWORD|SSLMODE)=\" $APP_DIR/backend/.env > $DB_CONF'"
  [ "$(stat -c '%U:%a' "$DB_CONF")" = "root:600" ] ||
    die "$DB_CONF must be owner root, mode 600: sudo chown root:root $DB_CONF && sudo chmod 600 $DB_CONF"
  DB_HOST="$(env_get DB_HOST "$DB_CONF")"
  DB_PORT="$(env_get DB_PORT "$DB_CONF")"
  DB_DATABASE="$(env_get DB_DATABASE "$DB_CONF")"
  DB_USERNAME="$(env_get DB_USERNAME "$DB_CONF")"
  DB_PASSWORD="$(env_get DB_PASSWORD "$DB_CONF")"
  DB_SSLMODE="$(env_get DB_SSLMODE "$DB_CONF")"
  for v in DB_HOST DB_DATABASE DB_USERNAME DB_PASSWORD; do
    [ -n "${!v}" ] || die "$v is empty in $DB_CONF"
  done
}

# ---------------------------------------------------------------------
# Application files: the same copy and checksum rules as Script 2
# ---------------------------------------------------------------------
copy_app() {   # copy_app DEST: $APP_DIR without vendor, node_modules, storage, .env
  mkdir -p "$1" &&
  tar -C "$APP_DIR" --exclude=./backend/vendor --exclude='node_modules' \
      --exclude=./backend/storage --exclude=./backend/.env -cf - . | tar -C "$1" -xpf -
}
make_sums() {  # make_sums DIR FILE: SHA-256 of every file under DIR, paths relative to DIR
  (cd "$1" && find . -type f -print0 | LC_ALL=C sort -z | xargs -0 -r sha256sum) >"$2"
}
check_sums() { # check_sums DIR FILE: prints how many files under DIR differ from FILE
  (cd "$1" 2>/dev/null || { echo "FAILED: folder $1 missing"; exit 0; }
   sha256sum -c "$2" 2>&1) | grep -vc ': OK$'
}

# ---------------------------------------------------------------------
# 1. Options
# ---------------------------------------------------------------------
FILE=""; LATEST="no"; DO_DB="yes"; DO_FILES="yes"; WITH_ENV="no"; ASSUME_YES="no"; LIST="no"
while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help)    usage; exit 0 ;;
    --latest)     LATEST="yes" ;;
    --db-only)    DO_FILES="no" ;;
    --files-only) DO_DB="no" ;;
    --with-env)   WITH_ENV="yes" ;;
    --yes)        ASSUME_YES="yes" ;;
    --list)       LIST="yes" ;;
    -*)           echo "ERROR: unknown option: $1" >&2; usage >&2; exit 2 ;;
    *)            [ -z "$FILE" ] || { echo "ERROR: give only one FILE" >&2; usage >&2; exit 2; }
                  FILE="$1" ;;
  esac
  shift
done
if [ "$DO_DB" = "no" ] && [ "$DO_FILES" = "no" ]; then
  echo "ERROR: --db-only and --files-only cannot be used together" >&2; usage >&2; exit 2
fi
if [ "$LIST" = "no" ]; then
  if [ -z "$FILE" ] && [ "$LATEST" = "no" ]; then
    echo "ERROR: give a FILE or --latest" >&2; usage >&2; exit 2
  elif [ -n "$FILE" ] && [ "$LATEST" = "yes" ]; then
    echo "ERROR: give a FILE or --latest, not both" >&2; usage >&2; exit 2
  fi
fi

# ---------------------------------------------------------------------
# 2. Requirement checks
# ---------------------------------------------------------------------
[ "$(id -u)" -eq 0 ] || die "this script must be run as root: sudo ./$SCRIPT_NAME"
load_config
mkdir -p "$LOG_DIR" && chmod 750 "$LOG_DIR"
for t in tar gzip sha256sum flock curl awk; do
  command -v "$t" >/dev/null || die "the command '$t' is missing: sudo apt install -y $t"
done
for t in pg_dump pg_restore psql; do
  [ -x "$PG_BIN/$t" ] || die "$PG_BIN/$t not found. Install the client tools (Script 1 guide, Part D3) or fix PG_BIN in $CONF"
done
case "$APP_DIR" in
  /var/www/?*|/srv/?*|/opt/?*) ;;
  *) die "APP_DIR=$APP_DIR does not look like the app folder (expected /var/www/cart-ni-isko)" ;;
esac
[ -d "$APP_DIR/backend" ] || die "$APP_DIR/backend not found. Run Script 1 first."
[ -d "$BACKUP_DIR" ] || die "$BACKUP_DIR not found. Make a backup with Script 2 first."
case "$RESTORE_UNDO_KEEP" in ''|*[!0-9]*) die "RESTORE_UNDO_KEEP must be a whole number in $CONF" ;; esac

# Backup and restore share one lock, so they never run at the same time
exec 9>/run/lock/cart-ni-isko-backup.lock
flock -n 9 || die "a backup or restore is already running; wait for it to finish"

WORK="$(mktemp -d /tmp/cart-ni-isko-restore.XXXXXX)"

if [ "$LIST" = "yes" ]; then
  say "Archives in $BACKUP_DIR (newest first)"
  ls -1t "$BACKUP_DIR"/cart-ni-isko-backup-*.tar.gz "$BACKUP_DIR"/cart-ni-isko-prerestore-*.tar.gz 2>/dev/null |
    while read -r f; do printf '  %-52s %6s  %s\n' "$(basename "$f")" \
      "$(du -h "$f" | cut -f1)" "$(date -r "$f" '+%F %T')"; done
  exit 0
fi

if [ "$LATEST" = "yes" ]; then
  FILE="$(ls -1t "$BACKUP_DIR"/cart-ni-isko-backup-*.tar.gz 2>/dev/null | head -n 1)"
  [ -n "$FILE" ] || die "no backups in $BACKUP_DIR. Make one with Script 2 first."
fi
[ -f "$FILE" ] || die "$FILE not found (see: sudo ./$SCRIPT_NAME --list)"
FILE="$(readlink -f "$FILE")"

# ---------------------------------------------------------------------
# 3. Verify the archive (the same checks as Script 2)
# ---------------------------------------------------------------------
count_dump_rows() {  # prints "table|rows" for every table in a dump, sorted
  "$PG_BIN/pg_restore" --data-only --file=- "$1" 2>/dev/null | awk '
    /^COPY / { t = $2; sub(/^public\./, "", t); gsub(/"/, "", t); n = 0; inside = 1; next }
    inside && /^\\\.$/ { print t "|" n; inside = 0; next }
    inside { n++ }' | LC_ALL=C sort
}

NAME="$(basename "$FILE")"; TOP="${NAME%.tar.gz}"; SRC="$WORK/src/$TOP"
say "Verifying $NAME"
(cd "$(dirname "$FILE")" && sha256sum -c --quiet "$NAME.sha256") >/dev/null 2>&1 ||
  die "checksum missing or different for $NAME: the file is damaged or was changed. Use another backup."
ok "checksum matches $NAME.sha256"
mkdir -p "$WORK/src"
tar -xzf "$FILE" -C "$WORK/src" 2>/dev/null || die "the archive cannot be opened (tar/gzip error)"
for part in MANIFEST.txt database.dump table-counts.txt files/backend.env; do
  [ -s "$SRC/$part" ] || die "part missing or empty in the archive: $part"
done
ok "archive opens and has MANIFEST, database.dump, table-counts, .env"
HAS_APP="no"
if [ -s "$SRC/files/app.sha256" ]; then
  HAS_APP="yes"
  for d in app storage-app; do
    [ -f "$SRC/files/$d.sha256" ] || continue
    [ "$(check_sums "$SRC/files/$d" "$SRC/files/$d.sha256")" -eq 0 ] ||
      die "files in the archive's $d/ differ from $d.sha256: the archive is incomplete. Use another backup."
  done
  ok "$(cat "$SRC"/files/*.sha256 | wc -l) application and uploaded files match their SHA-256 checksums"
else
  warn "this backup was made by an older Script 2 and has no application files; only data and uploads are restored"
fi
"$PG_BIN/pg_restore" --list "$SRC/database.dump" >"$WORK/toc" 2>/dev/null ||
  die "pg_restore cannot read database.dump"
[ "$(count_dump_rows "$SRC/database.dump")" = "$(cat "$SRC/table-counts.txt")" ] ||
  die "row counts in the dump differ from table-counts.txt. Use another backup."
B_TABLES="$(wc -l <"$SRC/table-counts.txt")"
B_ROWS="$(awk -F'|' '{s+=$2} END {print s+0}' "$SRC/table-counts.txt")"
ok "database.dump is readable: $B_TABLES tables, $B_ROWS rows"

# ---------------------------------------------------------------------
# 4. Database settings (from db.conf, root mode 600)
# ---------------------------------------------------------------------
ENV_FILE="$APP_DIR/backend/.env"
if [ ! -f "$ENV_FILE" ]; then
  warn "$ENV_FILE is missing: it will be restored from the backup"
  WITH_ENV="yes"
fi
load_db
esc() { printf '%s' "$1" | sed 's/[\\:]/\\&/g'; }
printf '%s:%s:%s:%s:%s\n' "$(esc "$DB_HOST")" "${DB_PORT:-5432}" "$(esc "$DB_DATABASE")" \
  "$(esc "$DB_USERNAME")" "$(esc "$DB_PASSWORD")" >"$WORK/pgpass"
unset DB_PASSWORD PGPASSWORD PGSERVICE PGSERVICEFILE   # use only the values above
export PGPASSFILE="$WORK/pgpass" PGHOST="$DB_HOST" PGPORT="${DB_PORT:-5432}" \
       PGDATABASE="$DB_DATABASE" PGUSER="$DB_USERNAME" PGSSLMODE="${DB_SSLMODE:-require}" \
       PGCONNECT_TIMEOUT=15
PSQL=("$PG_BIN/psql" -X -A -t -v ON_ERROR_STOP=1)

live_counts() {      # prints "table|rows" for every table now in the database
  "${PSQL[@]}" -F'|' 2>"$WORK/err" <<'SQL' | LC_ALL=C sort
SELECT format('SELECT %L, count(*) FROM public.%I', table_name, table_name)
FROM information_schema.tables
WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
ORDER BY table_name \gexec
SQL
}

# ---------------------------------------------------------------------
# 5. Pre-flight: database answers, versions fit, show what will happen
# ---------------------------------------------------------------------
say "Checking the database connection ($DB_USERNAME at $DB_HOST)"
SERVER_NUM="$("${PSQL[@]}" -c 'SHOW server_version_num' 2>"$WORK/err")" ||
  die "cannot reach the database: $(errline)"
SERVER_MAJOR=$((SERVER_NUM / 10000))
DUMP_MAJOR="$("$PG_BIN/pg_dump" --version | grep -oE '[0-9]+' | head -1)"
[ "$DUMP_MAJOR" -ge "$SERVER_MAJOR" ] ||
  die "pg_restore $DUMP_MAJOR is older than the server ($SERVER_MAJOR): install postgresql-client-$SERVER_MAJOR and set PG_BIN"
live_counts >"$WORK/before.txt" || die "counting rows failed: $(errline)"
ok "database answers: PostgreSQL $SERVER_MAJOR, now $(wc -l <"$WORK/before.txt") tables, $(awk -F'|' '{s+=$2} END {print s+0}' "$WORK/before.txt") rows"

FROM_DB="$(awk '/^database:/ {print $2}' "$SRC/MANIFEST.txt")"
[ -z "$FROM_DB" ] || [ "$FROM_DB" = "$DB_USERNAME" ] ||
  warn "this backup was made from database user $FROM_DB, but you are restoring into $DB_USERNAME"

echo
echo "  Backup : $NAME"
echo "           $(grep -m1 '^made:' "$SRC/MANIFEST.txt")"
echo "           $B_TABLES tables, $B_ROWS rows"
echo "  Target : $DB_USERNAME at $DB_HOST, and $APP_DIR"
echo "  Will   : $( [ "$DO_DB" = yes ] && echo -n 'replace the database tables; ')$( [ "$DO_FILES" = yes ] && echo -n 'restore the application and uploaded files; ')$( [ "$WITH_ENV" = yes ] && echo -n 'replace backend/.env; ')"
echo "           (the current state is saved first as an undo archive)"
echo
if [ "$ASSUME_YES" = "no" ]; then
  [ -t 0 ] || die "no terminal to ask for confirmation: add --yes"
  read -r -p "Type RESTORE to continue, anything else to stop: " answer
  [ "$answer" = "RESTORE" ] || { echo "Stopped. Nothing was changed."; log_line "CANCELLED file=$NAME"; exit 0; }
fi

# ---------------------------------------------------------------------
# 6. Save the current state as an undo archive
# ---------------------------------------------------------------------
UNDO="cart-ni-isko-prerestore-$STAMP"
say "Saving the current state as $UNDO.tar.gz (undo)"
mkdir -p "$WORK/undo/$UNDO/files"
"$PG_BIN/pg_dump" --format=custom --schema=public --no-owner --no-privileges \
  --file="$WORK/undo/$UNDO/database.dump" 2>"$WORK/err" || die "pg_dump of the current database failed: $(errline)"
count_dump_rows "$WORK/undo/$UNDO/database.dump" >"$WORK/undo/$UNDO/table-counts.txt"
if [ -f "$ENV_FILE" ]; then cp -p "$ENV_FILE" "$WORK/undo/$UNDO/files/backend.env"
else cp -p "$SRC/files/backend.env" "$WORK/undo/$UNDO/files/backend.env"; fi
copy_app "$WORK/undo/$UNDO/files/app" || die "copying the current application files failed"
make_sums "$WORK/undo/$UNDO/files/app" "$WORK/undo/$UNDO/files/app.sha256"
if [ -d "$APP_DIR/backend/storage/app" ]; then
  cp -a "$APP_DIR/backend/storage/app" "$WORK/undo/$UNDO/files/storage-app"
  make_sums "$WORK/undo/$UNDO/files/storage-app" "$WORK/undo/$UNDO/files/storage-app.sha256"
fi
{
  echo "Cart ni Isko undo archive $UNDO"
  echo "made:      $(date '+%F %T %Z') on $(hostname), before restoring $NAME"
  echo "database:  $DB_USERNAME at $DB_HOST (PostgreSQL $SERVER_MAJOR)"
  echo "restore:   sudo ./$SCRIPT_NAME $BACKUP_DIR/$UNDO.tar.gz   (puts this state back)"
  echo "WARNING:   holds passwords and customer personal data. Keep it private (RA 10173)."
} >"$WORK/undo/$UNDO/MANIFEST.txt"
tar -czf "$BACKUP_DIR/$UNDO.tar.gz" -C "$WORK/undo" "$UNDO" || die "could not write the undo archive"
(cd "$BACKUP_DIR" && sha256sum "$UNDO.tar.gz" >"$UNDO.tar.gz.sha256")
chmod 600 "$BACKUP_DIR/$UNDO.tar.gz" "$BACKUP_DIR/$UNDO.tar.gz.sha256"
ok "$BACKUP_DIR/$UNDO.tar.gz ($(du -h "$BACKUP_DIR/$UNDO.tar.gz" | cut -f1))"
log_line "UNDO SAVED file=$UNDO.tar.gz"

# ---------------------------------------------------------------------
# 7. Restore the database (one transaction: all or nothing)
# ---------------------------------------------------------------------
if [ "$DO_DB" = "yes" ]; then
  say "Restoring the database tables (pg_restore --clean, single transaction)"
  # Leave out the entries for the public schema itself: Supabase owns it, and
  # dropping it would also drop the permissions Supabase set on it.
  grep -vE ' SCHEMA - public | COMMENT - SCHEMA public ' "$WORK/toc" >"$WORK/toc.use"
  "$PG_BIN/pg_restore" --clean --if-exists --no-owner --no-privileges \
    --single-transaction --exit-on-error --use-list="$WORK/toc.use" \
    --dbname="$DB_DATABASE" "$SRC/database.dump" 2>"$WORK/err" ||
    die "pg_restore failed, so the database was left unchanged: $(errline)"
  ok "database tables replaced with the backup's"
fi

# ---------------------------------------------------------------------
# 8. Restore the files
# ---------------------------------------------------------------------
if [ "$DO_FILES" = "yes" ] && [ "$HAS_APP" = "yes" ]; then
  say "Restoring the application files to $APP_DIR"
  # Copy over the current files: deleted or changed files come back with the
  # owner and mode they had in the backup (the archive keeps them). vendor,
  # node_modules and storage are not touched here.
  cp -a "$SRC/files/app/." "$APP_DIR/" || die "copying the application files failed"
  ok "$(wc -l <"$SRC/files/app.sha256") application files restored (owners and modes as in the backup)"
fi
if [ "$DO_FILES" = "yes" ]; then
  say "Restoring uploaded files to $APP_DIR/backend/storage/app"
  if [ -d "$SRC/files/storage-app" ]; then
    rm -rf -- "$APP_DIR/backend/storage/app"
    cp -a "$SRC/files/storage-app" "$APP_DIR/backend/storage/app" || die "copying the uploaded files failed"
    chown -R "$WEB_USER:$WEB_GROUP" "$APP_DIR/backend/storage/app"
    find "$APP_DIR/backend/storage/app" -type d -exec chmod 770 {} +
    find "$APP_DIR/backend/storage/app" -type f -exec chmod 660 {} +
    ok "$(find "$APP_DIR/backend/storage/app" -type f | wc -l) files restored ($WEB_USER, 770/660)"
  else
    warn "the backup has no uploaded files (storage-app); left the current ones in place"
  fi
fi
if [ "$WITH_ENV" = "yes" ]; then
  say "Restoring $ENV_FILE"
  install -o root -g "$WEB_GROUP" -m 640 "$SRC/files/backend.env" "$ENV_FILE" || die "could not write $ENV_FILE"
  ok "$ENV_FILE restored (root:$WEB_GROUP, 640)"
elif ! cmp -s "$ENV_FILE" "$SRC/files/backend.env"; then
  warn ".env on the server differs from the backup's (kept the server's; use --with-env to replace it)"
fi
for f in "$SRC"/files/cart-ni-isko.conf "$SRC"/files/nginx/* "$SRC"/files/systemd/*; do
  [ -f "$f" ] || continue
  case "$f" in
    */files/cart-ni-isko.conf) live="$CONF" ;;
    */files/nginx/*)           live="/etc/nginx/sites-available/$(basename "$f")" ;;
    *)                         live="/etc/systemd/system/$(basename "$f")" ;;
  esac
  [ -f "$live" ] && ! cmp -s "$f" "$live" &&
    warn "$live differs from the backup (not changed; Script 1 manages it)"
done

# ---------------------------------------------------------------------
# 9. Let the app see the restored data
# ---------------------------------------------------------------------
say "Clearing Laravel's cache"
if command -v php >/dev/null && [ -f "$APP_DIR/backend/artisan" ]; then
  if [ "$WITH_ENV" = "yes" ]; then
    (cd "$APP_DIR/backend" && runuser -u "$WEB_USER" -- php artisan config:cache) >"$WORK/err" 2>&1 ||
      warn "php artisan config:cache failed: $(errline)"
  fi
  if (cd "$APP_DIR/backend" && runuser -u "$WEB_USER" -- php artisan cache:clear) >"$WORK/err" 2>&1; then
    ok "cache cleared, so pages show the restored data"
  else
    warn "php artisan cache:clear failed: $(errline)"
  fi
else
  warn "php or artisan not found: cache not cleared"
fi
if systemctl is-active --quiet "php$PHP_VER-fpm" 2>/dev/null; then
  systemctl reload "php$PHP_VER-fpm" && ok "php$PHP_VER-fpm reloaded"
fi

# ---------------------------------------------------------------------
# 10. Final checks: does the restored data match the backup?
# ---------------------------------------------------------------------
say "Checking the result"
if [ "$DO_FILES" = "yes" ] && [ "$HAS_APP" = "yes" ]; then
  n="$(check_sums "$APP_DIR" "$SRC/files/app.sha256")"
  if [ "$n" -eq 0 ]; then ok "every application file matches the backup (SHA-256, $(wc -l <"$SRC/files/app.sha256") files)"
  else bad "$n application file(s) differ from the backup: (cd $APP_DIR && sudo sha256sum -c --quiet <list>)"; fi
  if [ -f "$SRC/files/storage-app.sha256" ]; then
    n="$(check_sums "$APP_DIR/backend/storage/app" "$SRC/files/storage-app.sha256")"
    if [ "$n" -eq 0 ]; then ok "every uploaded file matches the backup (SHA-256, $(wc -l <"$SRC/files/storage-app.sha256") files)"
    else bad "$n uploaded file(s) differ from the backup"; fi
  fi
fi
if [ "$DO_DB" = "yes" ]; then
  live_counts >"$WORK/after.txt" || die "counting rows failed: $(errline)"
  if [ "$(cat "$WORK/after.txt")" = "$(cat "$SRC/table-counts.txt")" ]; then
    ok "row counts match the backup ($B_TABLES tables, $B_ROWS rows)"
  else
    missing="$(LC_ALL=C comm -23 "$SRC/table-counts.txt" "$WORK/after.txt" | head -n 3 | tr '\n' ' ')"
    if [ -n "$missing" ]; then
      bad "row counts differ from the backup: $missing"
    else
      warn "the database also has tables the backup does not have (left as they are)"
    fi
  fi
fi
CODE="$(curl -s -o /dev/null -m 20 -w '%{http_code}' "$RESTORE_CHECK_URL")"
if [ "$CODE" = "200" ]; then ok "API $RESTORE_CHECK_URL answers (HTTP 200)"
else bad "API $RESTORE_CHECK_URL answered HTTP $CODE"; fi

# Keep only the newest RESTORE_UNDO_KEEP undo archives
ls -1t "$BACKUP_DIR"/cart-ni-isko-prerestore-*.tar.gz 2>/dev/null | tail -n +"$((RESTORE_UNDO_KEEP + 1))" |
  while read -r old; do rm -f -- "$old" "$old.sha256"; done

# ---------------------------------------------------------------------
# 11. Result
# ---------------------------------------------------------------------
if [ "$FAILS" -eq 0 ]; then
  log_line "RESTORE OK file=$NAME db=$DO_DB files=$DO_FILES env=$WITH_ENV undo=$UNDO.tar.gz warnings=$WARNS"
  echo "SUCCESS: restored from $NAME. Undo with: sudo ./$SCRIPT_NAME $BACKUP_DIR/$UNDO.tar.gz"
  exit 0
fi
log_line "RESTORE FAIL file=$NAME fails=$FAILS warnings=$WARNS undo=$UNDO.tar.gz"
echo "FAILURE: restored from $NAME, but $FAILS check(s) failed. Undo with: sudo ./$SCRIPT_NAME $BACKUP_DIR/$UNDO.tar.gz"
exit 3
