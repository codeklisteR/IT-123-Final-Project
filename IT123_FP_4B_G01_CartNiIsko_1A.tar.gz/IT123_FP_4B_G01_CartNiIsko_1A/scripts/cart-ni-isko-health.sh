#!/bin/bash
# =====================================================================
# cart-ni-isko-health.sh - Script 5: Health Report
#
# Purpose : Checks, right now, everything Cart ni Isko needs to work and
#           prints one report with [OK], [WARN] or [FAIL] per check: services,
#           web pages and API (with response times), the Supabase database,
#           CPU, memory, disk, clock, updates, backups and recent app errors.
#           Ends with HEALTHY, HEALTHY WITH WARNINGS or UNHEALTHY. The report
#           is saved in REPORT_DIR and one line goes to health.log.
# Authors : Group G01
#           Brucelo, Alyssa Mae B.; Ebuenga, Kristel Ann B.;
#           Fenis, Austin B.; Marfil, John Marvin G.
# Usage   : sudo ./cart-ni-isko-health.sh [--quiet] [--no-save] [--install-timer]
#           [--help]
# Needs   : Script 1 already run. Only reads; changes nothing in the app.
# AI note : Drafted with help from Claude (Anthropic AI). Every line was
#           reviewed, tested and can be explained by the group (Section 5.6).
# =====================================================================

set -o pipefail          # a pipe fails if ANY command in it fails
umask 027                # reports: root can write, group adm can read

SCRIPT_NAME="$(basename "$0")"
CONF="${CARTNIISKO_CONF:-/etc/cart-ni-isko/cart-ni-isko.conf}"   # same variable as Script 1
OKS=0; WARNS=0; FAILS=0; QUIET="no"

usage() {
  cat <<EOF
Usage: sudo ./$SCRIPT_NAME [OPTION]...

Checks the health of the Cart ni Isko server now and prints a report.

Options:
  --quiet           print only problems ([WARN]/[FAIL]) and the result line
  --no-save         do not save the report in REPORT_DIR
  --install-timer   also run this check every hour (systemd timer)
  -h, --help        show this help and exit

Examples:
  sudo ./$SCRIPT_NAME
  sudo ./$SCRIPT_NAME --quiet

Exit status: 0 healthy (warnings allowed), 1 error, 2 bad option,
             3 unhealthy (at least one [FAIL]).
EOF
}

die()  { echo "ERROR: $*" >&2; exit 1; }
ok()   { OKS=$((OKS + 1));     [ "$QUIET" = yes ] || printf '  [OK]   %s\n' "$*"; }
warn() { WARNS=$((WARNS + 1)); printf '  [WARN] %s\n' "$*"; }
bad()  { FAILS=$((FAILS + 1)); printf '  [FAIL] %s\n' "$*"; }
section() { [ "$QUIET" = yes ] || printf '\n== %s\n' "$*"; }
# level VALUE WARN FAIL MESSAGE: OK below WARN, WARN below FAIL, else FAIL
level() { if [ "$1" -ge "$3" ]; then bad "$4"; elif [ "$1" -ge "$2" ]; then warn "$4"; else ok "$4"; fi; }

env_get() {    # env_get KEY FILE  -> prints the value, quotes removed
  local v
  v="$(grep -m1 -E "^$1=" "$2" | cut -d= -f2- | tr -d '\r')"
  case "$v" in \"*\") v="${v#\"}"; v="${v%\"}" ;; \'*\') v="${v#\'}"; v="${v%\'}" ;; esac
  printf '%s' "$v"
}

load_config() {          # same rules as Scripts 1 to 4
  [ -f "$CONF" ] || die "$CONF not found. Run Script 1 (cart-ni-isko-install.sh) first."
  [ "$(stat -c '%U:%a' "$CONF")" = "root:600" ] ||
    die "$CONF must be owner root, mode 600: sudo chown root:root $CONF && sudo chmod 600 $CONF"
  # shellcheck source=/dev/null
  . "$CONF"
  APP_DIR="${APP_DIR:-/var/www/cart-ni-isko}"
  BACKUP_DIR="${BACKUP_DIR:-/var/backups/cart-ni-isko}"
  APP_NAME="${APP_NAME:-cart-ni-isko}"
  WEB_USER="${WEB_USER:-www-data}"; WEB_GROUP="${WEB_GROUP:-www-data}"
  LOG_DIR="${LOG_DIR:-${REPORT_DIR:-/var/log/cart-ni-isko-toolkit}}"   # Script 1 creates REPORT_DIR
  REPORT_DIR="${REPORT_DIR:-$LOG_DIR}"
  REPORT_KEEP_DAYS="${REPORT_KEEP_DAYS:-30}"
  PG_BIN="${PG_BIN:-/usr/lib/postgresql/17/bin}"
  PHP_VER="${PHP_VER:-8.5}"
  HEALTH_BASE_URL="${HEALTH_BASE_URL:-http://127.0.0.1}"
  DISK_WARN_PCT="${DISK_WARN_PCT:-${DISK_THRESHOLD:-80}}";  DISK_FAIL_PCT="${DISK_FAIL_PCT:-90}"
  MEM_WARN_PCT="${MEM_WARN_PCT:-85}";    MEM_FAIL_PCT="${MEM_FAIL_PCT:-95}"
  SLOW_MS="${SLOW_MS:-1500}"
  BACKUP_MAX_AGE_H="${BACKUP_MAX_AGE_H:-26}"
  SERVICES="${SERVICES:-php$PHP_VER-fpm nginx $APP_NAME-scheduler}"   # from Script 1's config
  API_CHECK_PATH="${API_CHECK_PATH:-/api/products/filter}"
  SCHEDULER_CHECK_PATH="${SCHEDULER_CHECK_PATH:-/api/health/scheduler}"
  DB_CONF="${DB_CONF:-$(dirname "$CONF")/db.conf}"   # written by Script 1
}

# ---------------------------------------------------------------------
# 1. Options
# ---------------------------------------------------------------------
SAVE="yes"; TIMER="no"
while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help)       usage; exit 0 ;;
    --quiet)         QUIET="yes" ;;
    --no-save)       SAVE="no" ;;
    --install-timer) TIMER="yes" ;;
    *)               echo "ERROR: unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

# ---------------------------------------------------------------------
# 2. Requirement checks
# ---------------------------------------------------------------------
[ "$(id -u)" -eq 0 ] || die "this script must be run as root: sudo ./$SCRIPT_NAME"
load_config
for t in curl awk df free nproc; do
  command -v "$t" >/dev/null || die "the command '$t' is missing"
done
for v in DISK_WARN_PCT DISK_FAIL_PCT MEM_WARN_PCT MEM_FAIL_PCT SLOW_MS BACKUP_MAX_AGE_H REPORT_KEEP_DAYS; do
  [[ "${!v}" =~ ^[0-9]+$ ]] || die "$v must be a whole number in $CONF"
done
WORK="$(mktemp -d /tmp/cart-ni-isko-health.XXXXXX)"
trap 'rm -rf -- "$WORK"' EXIT

# ---------------------------------------------------------------------
# 3. The checks
# ---------------------------------------------------------------------
checks() {
  echo "Cart ni Isko health report"
  echo "Time   : $(date '+%F %T %Z')   Server: $(hostname)   Up: $(uptime -p 2>/dev/null | sed 's/^up //')"

  # 3a. Services: each must be running
  section "Services"
  for u in $SERVICES; do
    if systemctl is-active --quiet "$u" 2>/dev/null; then ok "$u is running"
    else bad "$u is not running: sudo systemctl status $u"; fi
  done
  if systemctl is-active --quiet cart-ni-isko-backup.timer 2>/dev/null; then ok "daily backup timer is on"
  else warn "daily backup timer is off: sudo ./cart-ni-isko-backup.sh --install-timer"; fi

  # 3b. Web pages and API: HTTP status and response time
  section "Website and API ($HEALTH_BASE_URL)"
  for path in / "$API_CHECK_PATH" "$SCHEDULER_CHECK_PATH"; do
    read -r code secs < <(curl -s -o /dev/null -m 20 -w '%{http_code} %{time_total}' "$HEALTH_BASE_URL$path")
    ms="$(awk -v s="${secs:-0}" 'BEGIN {printf "%d", s * 1000}')"
    if [ "$code" != "200" ]; then bad "$path answered HTTP ${code:-000}"
    elif [ "$ms" -ge "$SLOW_MS" ]; then warn "$path answered HTTP 200 but slowly ($ms ms)"
    else ok "$path answered HTTP 200 in $ms ms"; fi
  done
  code="$(curl -s -o /dev/null -m 10 -w '%{http_code}' "$HEALTH_BASE_URL/.env")"
  if [ "$code" = "200" ]; then bad "/.env can be downloaded (HTTP 200): secrets are exposed"
  else ok "/.env is blocked (HTTP $code)"; fi

  # 3c. Database: connect with the toolkit's settings (db.conf, root mode 600)
  section "Database (Supabase)"
  ENV_FILE="$APP_DIR/backend/.env"
  if [ ! -f "$ENV_FILE" ]; then bad "$ENV_FILE not found: the app cannot reach the database"; fi
  if [ ! -f "$DB_CONF" ]; then warn "$DB_CONF not found: database not checked (Script 1 writes it)"
  elif [ "$(stat -c '%U:%a' "$DB_CONF")" != "root:600" ]; then bad "$DB_CONF must be owner root, mode 600"
  elif [ ! -x "$PG_BIN/psql" ]; then warn "$PG_BIN/psql not found: database not checked (Script 1 guide, D3)"
  else
    h="$(env_get DB_HOST "$DB_CONF")"; u="$(env_get DB_USERNAME "$DB_CONF")"
    d="$(env_get DB_DATABASE "$DB_CONF")"; p="$(env_get DB_PORT "$DB_CONF")"; p="${p:-5432}"
    printf '%s:%s:%s:%s:%s\n' "$h" "$p" "$d" "$u" "$(env_get DB_PASSWORD "$DB_CONF" | sed 's/[\\:]/\\&/g')" >"$WORK/pgpass"
    chmod 600 "$WORK/pgpass"      # libpq ignores a password file others can read
    start="$(date +%s%N)"
    if n="$(env -u PGPASSWORD PGPASSFILE="$WORK/pgpass" PGCONNECT_TIMEOUT=10 \
        PGSSLMODE="$(env_get DB_SSLMODE "$DB_CONF" | sed 's/^$/require/')" \
        "$PG_BIN/psql" -X -A -t -w -h "$h" -p "$p" -U "$u" -d "$d" \
        -c "SELECT count(*) FROM information_schema.tables WHERE table_schema='public'" 2>"$WORK/err")"; then
      ms=$(( ($(date +%s%N) - start) / 1000000 ))
      if [ "$ms" -ge "$SLOW_MS" ]; then warn "database answers slowly ($ms ms), $n tables"
      else ok "database answers in $ms ms, $n tables ($u)"; fi
    else
      bad "cannot reach the database: $(grep -m1 -iE 'fatal|error' "$WORK/err" || tail -n 1 "$WORK/err")"
    fi
    # The app (.env) and the toolkit (db.conf) must point at the same database
    if [ -f "$ENV_FILE" ]; then
      same="yes"
      for k in DB_HOST DB_DATABASE DB_USERNAME DB_PASSWORD; do
        [ "$(env_get "$k" "$DB_CONF")" = "$(env_get "$k" "$ENV_FILE")" ] || same="no"
      done
      if [ "$same" = "yes" ]; then ok "db.conf and the app's .env point at the same database"
      else warn "db.conf and the app's .env differ: run Script 1 with --force to rewrite $DB_CONF"; fi
    fi
  fi

  # 3d. System resources
  section "System resources"
  cores="$(nproc)"; load="$(awk '{print $1}' /proc/loadavg)"
  pct="$(awk -v l="$load" -v c="$cores" 'BEGIN {printf "%d", l * 100 / c}')"
  level "$pct" 100 200 "CPU load $load on $cores core(s) ($pct% of capacity, 1-minute average)"
  mem="$(free | awk '/^Mem:/ {printf "%d", ($2 - $7) * 100 / $2}')"
  level "$mem" "$MEM_WARN_PCT" "$MEM_FAIL_PCT" "memory $mem% used ($(free -h | awk '/^Mem:/ {print $7}') available)"
  swap="$(free | awk '/^Swap:/ {if ($2 > 0) printf "%d", $3 * 100 / $2; else print 0}')"
  level "$swap" 50 90 "swap $swap% used"
  for m in / /var; do
    d="$(df -P "$m" | awk 'NR==2 {gsub("%", "", $5); print $5}')"
    level "$d" "$DISK_WARN_PCT" "$DISK_FAIL_PCT" "disk $m $d% full ($(df -Ph "$m" | awk 'NR==2 {print $4}') free)"
  done
  i="$(df -Pi / | awk 'NR==2 {gsub("%", "", $5); print ($5 == "-" ? 0 : $5)}')"
  level "$i" "$DISK_WARN_PCT" "$DISK_FAIL_PCT" "inodes on / $i% used"

  # 3e. Clock, updates, reboot
  section "System maintenance"
  if [ "$(timedatectl show -p NTPSynchronized --value 2>/dev/null)" = "yes" ]; then ok "clock is synchronised ($(date +%Z))"
  else warn "clock is not synchronised: sudo timedatectl set-ntp true"; fi
  if command -v apt-get >/dev/null; then
    apt-get -s -o Debug::NoLocking=1 upgrade 2>/dev/null | grep '^Inst ' >"$WORK/upd"
    all="$(wc -l <"$WORK/upd")"; sec="$(grep -ci 'security' "$WORK/upd")"
    if [ "$sec" -gt 0 ]; then warn "$sec security update(s) waiting ($all in all): sudo apt update && sudo apt upgrade"
    elif [ "$all" -gt 0 ]; then ok "no security updates waiting ($all other update(s))"
    else ok "system is up to date (as of the last apt update)"; fi
  fi
  if [ -f /var/run/reboot-required ]; then warn "a reboot is needed to finish updates: sudo reboot"
  else ok "no reboot needed"; fi

  # 3f. Backups (Script 2)
  section "Backups"
  newest="$(ls -1t "$BACKUP_DIR"/cart-ni-isko-backup-*.tar.gz 2>/dev/null | head -n 1)"
  if [ -z "$newest" ]; then bad "no backup found in $BACKUP_DIR: sudo ./cart-ni-isko-backup.sh"
  else
    age=$(( ($(date +%s) - $(stat -c %Y "$newest")) / 3600 ))
    if [ "$age" -ge "$BACKUP_MAX_AGE_H" ]; then warn "newest backup is $age hours old: $(basename "$newest")"
    else ok "newest backup is $age hour(s) old: $(basename "$newest")"; fi
  fi
  last="$(grep -E ' BACKUP (OK|FAIL) ' "$LOG_DIR/backup.log" 2>/dev/null | tail -n 1)"
  case "$last" in
    *"BACKUP OK"*)   ok "last backup run verified OK (${last:0:16})" ;;
    *"BACKUP FAIL"*) bad "last backup run FAILED verification (${last:0:16}): see $LOG_DIR/backup.log" ;;
    *)               warn "no backup run recorded in $LOG_DIR/backup.log" ;;
  esac

  # 3g. Recent application errors (last 24 hours)
  section "Application errors (last 24 hours)"
  since="$(date -d '-24 hours' '+%F %T')"
  n="$(cat "$APP_DIR"/backend/storage/logs/laravel*.log 2>/dev/null |
       grep -E '^\[[0-9-]{10} [0-9:]{8}\] [a-z]+\.(ERROR|CRITICAL|ALERT|EMERGENCY):' |
       awk -v s="$since" 'substr($0, 2, 19) >= s' | wc -l)"
  level "$n" 1 50 "$n Laravel error(s) logged (details: sudo ./cart-ni-isko-logsummary.sh)"
  n5="$(awk -v a="$(date -d '-1 hour' '+%d/%b/%Y:%H')" -v b="$(date '+%d/%b/%Y:%H')" \
        '$9 ~ /^5/ && (substr($4, 2, 14) == a || substr($4, 2, 14) == b)' \
        "${NGINX_ACCESS_LOG:-/var/log/nginx/${APP_NAME}_access.log}" 2>/dev/null | wc -l)"
  level "$n5" 1 20 "$n5 server error(s) (HTTP 5xx) in the current and last hour"

  # 3h. Result
  echo
  if [ "$FAILS" -gt 0 ]; then RESULT="UNHEALTHY"; CODE="FAIL"
  elif [ "$WARNS" -gt 0 ]; then RESULT="HEALTHY WITH WARNINGS"; CODE="WARN"
  else RESULT="HEALTHY"; CODE="OK"; fi
  echo "RESULT: $RESULT ($OKS OK, $WARNS warning(s), $FAILS failure(s))"
  echo "$CODE $OKS $WARNS $FAILS" >"$WORK/result"   # the pipe to tee runs checks in a subshell
}

# ---------------------------------------------------------------------
# 4. Run, save the report, write one line to health.log
# ---------------------------------------------------------------------
mkdir -p "$LOG_DIR" && chmod 750 "$LOG_DIR"
if [ "$SAVE" = "yes" ]; then
  mkdir -p "$REPORT_DIR" && chmod 750 "$REPORT_DIR" || die "cannot create $REPORT_DIR"
  OUT="$REPORT_DIR/health-$(date +%Y-%m-%d_%H%M).txt"
  checks | tee "$OUT"; chmod 640 "$OUT"
  [ "$QUIET" = yes ] || echo "Saved: $OUT"
  find "$REPORT_DIR" -maxdepth 1 -name 'health-*.txt' -mtime +"$REPORT_KEEP_DAYS" -delete 2>/dev/null
else
  checks
fi
read -r RES OKN WN FN <"$WORK/result"
echo "$(date '+%F %T') HEALTH $RES ok=$OKN warnings=$WN fails=$FN" >>"$LOG_DIR/health.log"

# ---------------------------------------------------------------------
# 5. Optional: run every hour with a systemd timer
# ---------------------------------------------------------------------
if [ "$TIMER" = "yes" ]; then
  install -o root -g root -m 750 "$0" /usr/local/sbin/cart-ni-isko-health.sh
  printf '%s\n' '[Unit]' 'Description=Cart ni Isko health report (Script 5)' '' \
    '[Service]' 'Type=oneshot' 'ExecStart=/usr/local/sbin/cart-ni-isko-health.sh --quiet' \
    'SuccessExitStatus=3' >/etc/systemd/system/cart-ni-isko-health.service
  printf '%s\n' '[Unit]' 'Description=Run the Cart ni Isko health report every hour' '' \
    '[Timer]' 'OnCalendar=hourly' 'Persistent=true' '' '[Install]' 'WantedBy=timers.target' \
    >/etc/systemd/system/cart-ni-isko-health.timer
  chmod 644 /etc/systemd/system/cart-ni-isko-health.{service,timer}
  systemctl daemon-reload && systemctl enable --now cart-ni-isko-health.timer >/dev/null 2>&1 ||
    die "could not enable cart-ni-isko-health.timer: systemctl status cart-ni-isko-health.timer"
  echo "==> Hourly health timer installed; reports go to $REPORT_DIR"
fi

[ "$FN" -eq 0 ] && exit 0
exit 3
