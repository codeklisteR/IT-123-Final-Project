#!/bin/bash
# =====================================================================
# cart-ni-isko-backup.sh - Script 2: Backup and verify
#
# Purpose : Makes one dated backup archive of Cart ni Isko: the Supabase
#           database (all tables in the public schema, with their rows), the
#           application files (/var/www/cart-ni-isko without vendor and
#           node_modules), the secret settings (backend/.env), uploaded files
#           (backend/storage/app), and the server settings Script 1 wrote.
#           Then it VERIFIES the archive (checksum, archive contents, every
#           file's SHA-256, database dump readable, row counts match), deletes
#           old backups, and writes one summary line to the backup log.
# Authors : Group G01
#           Brucelo, Alyssa Mae B.; Ebuenga, Kristel Ann B.;
#           Fenis, Austin B.; Marfil, John Marvin G.
# Usage   : sudo ./cart-ni-isko-backup.sh [--verify FILE] [--list] [--no-prune]
#           [--install-timer] [--help]
# Needs   : Script 1 already run (config in /etc/cart-ni-isko, app deployed),
#           and the database settings in /etc/cart-ni-isko/db.conf (mode 600).
# AI note : Drafted with help from Claude (Anthropic AI). Every line was
#           reviewed, tested and can be explained by the group (Section 5.6).
# =====================================================================

set -o pipefail          # a pipe fails if ANY command in it fails
umask 077                # files this script creates are readable by root only

SCRIPT_NAME="$(basename "$0")"
CONF="${CARTNIISKO_CONF:-/etc/cart-ni-isko/cart-ni-isko.conf}"   # same variable as Script 1
STAMP="$(date +%Y-%m-%d_%H%M%S)"
WORK=""                  # temporary folder, removed by cleanup()
FAILS=0                  # number of failed verification checks
WARNS=0                  # number of warnings

usage() {
  cat <<EOF
Usage: sudo ./$SCRIPT_NAME [OPTION]

Backs up the Cart ni Isko database, application files, .env, uploads and
server settings into one archive in BACKUP_DIR, verifies it, and removes backups older than
BACKUP_KEEP_DAYS (always keeping the newest BACKUP_MIN_KEEP).

Options:
  --verify FILE     only verify an existing backup archive, make no new one
  --list            list the backups in BACKUP_DIR with size and date
  --no-prune        make and verify a backup but delete no old ones
  --install-timer   also run this backup every day at BACKUP_TIME (systemd timer)
  -h, --help        show this help and exit

Examples:
  sudo ./$SCRIPT_NAME
  sudo ./$SCRIPT_NAME --verify /var/backups/cart-ni-isko/cart-ni-isko-backup-2026-11-25_020000.tar.gz

Exit status: 0 backup made and verified, 1 error, 2 bad option,
             3 backup made but a verification check failed.
EOF
}

# ---------------------------------------------------------------------
# Message helpers
# ---------------------------------------------------------------------
say()  { echo "==> $*"; }
ok()   { echo "  [OK]   $*"; }
warn() { echo "  [WARN] $*"; WARNS=$((WARNS + 1)); }
bad()  { echo "  [FAIL] $*"; FAILS=$((FAILS + 1)); }
die()  { echo "ERROR: $*" >&2; log_line "ERROR $*"; exit 1; }

log_line() {   # one line per run in the backup log (read by Script 4)
  [ -n "${LOG_DIR:-}" ] && [ -d "$LOG_DIR" ] || return 0
  echo "$(date '+%F %T') $*" >>"$LOG_DIR/backup.log"
}

errline() {    # the most useful line of the last error output
  grep -m1 -iE 'fatal|error' "$WORK/err" || tail -n 1 "$WORK/err"
}

cleanup() {    # runs on every exit: delete the temporary folder
  [ -n "$WORK" ] && [ -d "$WORK" ] && rm -rf -- "$WORK"
}
trap cleanup EXIT

# ---------------------------------------------------------------------
# Read one value from a Laravel .env file without running it
# ---------------------------------------------------------------------
env_get() {    # env_get KEY FILE  -> prints the value, quotes removed
  local v
  v="$(grep -m1 -E "^$1=" "$2" | cut -d= -f2- | tr -d '\r')"
  case "$v" in
    \"*\") v="${v#\"}"; v="${v%\"}" ;;
    \'*\') v="${v#\'}"; v="${v%\'}" ;;
  esac
  printf '%s' "$v"
}

# ---------------------------------------------------------------------
# Load the shared toolkit config (same rules as Script 1)
# ---------------------------------------------------------------------
load_config() {
  [ -f "$CONF" ] || die "$CONF not found. Run Script 1 (cart-ni-isko-install.sh) first."
  [ "$(stat -c '%U:%a' "$CONF")" = "root:600" ] ||
    die "$CONF must be owner root, mode 600: sudo chown root:root $CONF && sudo chmod 600 $CONF"
  # shellcheck source=/dev/null
  . "$CONF"
  # Defaults for the Script 2 settings, used when a line is missing in the config
  APP_DIR="${APP_DIR:-/var/www/cart-ni-isko}"
  APP_SRC="${APP_SRC:-/opt/cart-ni-isko-source}"
  BACKUP_DIR="${BACKUP_DIR:-/var/backups/cart-ni-isko}"
  BACKUP_KEEP_DAYS="${BACKUP_KEEP_DAYS:-${BACKUP_KEEP:-14}}"
  BACKUP_MIN_KEEP="${BACKUP_MIN_KEEP:-3}"
  BACKUP_MIN_FREE_MB="${BACKUP_MIN_FREE_MB:-500}"
  BACKUP_TIME="${BACKUP_TIME:-02:00}"
  PG_BIN="${PG_BIN:-/usr/lib/postgresql/17/bin}"
  APP_NAME="${APP_NAME:-cart-ni-isko}"
  WEB_USER="${WEB_USER:-www-data}"; WEB_GROUP="${WEB_GROUP:-www-data}"
  LOG_DIR="${LOG_DIR:-${REPORT_DIR:-/var/log/cart-ni-isko-toolkit}}"   # Script 1 creates REPORT_DIR
  DB_CONF="${DB_CONF:-$(dirname "$CONF")/db.conf}"   # written by Script 1
}

# ---------------------------------------------------------------------
# Read the database settings from the toolkit's own owner-only file
# ---------------------------------------------------------------------
# Section 5.1: passwords are never written in a script; they are read from a
# file only its owner (root) can read. db.conf is never run (sourced), only read.
load_db() {
  [ -f "$DB_CONF" ] || die "$DB_CONF not found. Script 1 writes it; for an older install create it once:
  sudo sh -c 'umask 077; grep -E \"^DB_(HOST|PORT|DATABASE|USERNAME|PASSWORD|SSLMODE)=\" $APP_DIR/backend/.env > $DB_CONF'"
  [ "$(stat -c '%U:%a' "$DB_CONF")" = "root:600" ] ||
    die "$DB_CONF must be owner root, mode 600: sudo chown root:root $DB_CONF && sudo chmod 600 $DB_CONF"
  DB_HOST="$(env_get DB_HOST "$DB_CONF")"
  DB_PORT="$(env_get DB_PORT "$DB_CONF")"
  DB_DATABASE="$(env_get DB_DATABASE "$DB_CONF")"
  DB_USERNAME="$(env_get DB_USERNAME "$DB_CONF")"
  DB_PASSWORD="$(env_get DB_PASSWORD "$DB_CONF")"
  DB_SSLMODE="$(env_get DB_SSLMODE "$DB_CONF")"
  for v in DB_HOST DB_DATABASE DB_USERNAME DB_PASSWORD; do
    [ -n "${!v}" ] || die "$v is empty in $DB_CONF"
  done
}

# ---------------------------------------------------------------------
# Copy the application files (code), leaving out what can be rebuilt
# ---------------------------------------------------------------------
copy_app() {   # copy_app DEST: copies $APP_DIR to DEST without vendor, node_modules,
               # storage (backed up separately) and .env (backed up separately)
  mkdir -p "$1" &&
  tar -C "$APP_DIR" --exclude=./backend/vendor --exclude='node_modules' \
      --exclude=./backend/storage --exclude=./backend/.env -cf - . | tar -C "$1" -xpf -
}
make_sums() {  # make_sums DIR FILE: SHA-256 of every file under DIR, paths relative to DIR
  (cd "$1" && find . -type f -print0 | LC_ALL=C sort -z | xargs -0 -r sha256sum) >"$2"
}

# ---------------------------------------------------------------------
# 1. Options
# ---------------------------------------------------------------------
MODE="backup"; VERIFY_FILE=""; PRUNE="yes"; TIMER="no"
while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help)       usage; exit 0 ;;
    --verify)        [ -n "${2:-}" ] || { echo "ERROR: --verify needs a FILE" >&2; usage >&2; exit 2; }
                     MODE="verify"; VERIFY_FILE="$2"; shift ;;
    --list)          MODE="list" ;;
    --no-prune)      PRUNE="no" ;;
    --install-timer) TIMER="yes" ;;
    *)               echo "ERROR: unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

# ---------------------------------------------------------------------
# 2. Requirement checks
# ---------------------------------------------------------------------
[ "$(id -u)" -eq 0 ] || die "this script must be run as root: sudo ./$SCRIPT_NAME"
load_config
mkdir -p "$LOG_DIR" && chmod 750 "$LOG_DIR"
for t in tar gzip sha256sum flock df awk; do
  command -v "$t" >/dev/null || die "the command '$t' is missing: sudo apt install -y $t"
done
for t in pg_dump pg_restore psql; do
  [ -x "$PG_BIN/$t" ] || die "$PG_BIN/$t not found. Install the client tools (Script 1 guide, Part D3) or fix PG_BIN in $CONF"
done
case "$BACKUP_KEEP_DAYS$BACKUP_MIN_KEEP$BACKUP_MIN_FREE_MB" in
  *[!0-9]*) die "BACKUP_KEEP_DAYS, BACKUP_MIN_KEEP and BACKUP_MIN_FREE_MB must be whole numbers in $CONF" ;;
esac
[[ "$BACKUP_TIME" =~ ^([01][0-9]|2[0-3]):[0-5][0-9]$ ]] || die "BACKUP_TIME must look like 02:00 in $CONF"
case "$BACKUP_DIR" in
  /var/backups/*|/srv/*|/mnt/*|/media/*|/backup*) ;;
  *) die "BACKUP_DIR=$BACKUP_DIR is not a safe place for backups (use /var/backups/cart-ni-isko)" ;;
esac
mkdir -p "$BACKUP_DIR" && chown root:root "$BACKUP_DIR" && chmod 700 "$BACKUP_DIR" ||
  die "cannot create $BACKUP_DIR"

# Only one backup at a time (a timer run and a manual run must not overlap)
exec 9>/run/lock/cart-ni-isko-backup.lock
flock -n 9 || die "another backup is already running; wait for it to finish"

# ---------------------------------------------------------------------
# 3. Verification of one archive (used after a backup and by --verify)
# ---------------------------------------------------------------------
verify_archive() {   # verify_archive FILE  -> adds to FAILS on any problem
  local file="$1" dir name top
  dir="$(dirname "$file")"; name="$(basename "$file")"; top="${name%.tar.gz}"
  say "Verifying $name"

  # 3a. Checksum: the file is exactly the one that was written
  if [ -f "$file.sha256" ] && (cd "$dir" && sha256sum -c --quiet "$name.sha256") >/dev/null 2>&1; then
    ok "checksum matches $name.sha256"
  else
    bad "checksum missing or different: the file is damaged or was changed"
    return
  fi

  # 3b. The archive opens and holds every required part
  local check; check="$(mktemp -d "$WORK/verify.XXXX")"
  if ! tar -xzf "$file" -C "$check" 2>/dev/null; then
    bad "the archive cannot be opened (tar/gzip error)"; return
  fi
  local part missing=0
  for part in MANIFEST.txt database.dump table-counts.txt files/backend.env files/app.sha256; do
    [ -s "$check/$top/$part" ] || { bad "part missing or empty in the archive: $part"; missing=1; }
  done
  [ "$missing" -eq 0 ] && ok "archive opens and has MANIFEST, database.dump, table-counts, .env, app files"
  [ "$missing" -eq 0 ] || return

  # 3b2. Every application and uploaded file inside matches its SHA-256
  local sumf dirn nfiles=0
  for sumf in app storage-app; do
    [ -f "$check/$top/files/$sumf.sha256" ] || continue
    dirn="$check/$top/files/$sumf"; mkdir -p "$dirn"
    if (cd "$dirn" && sha256sum -c --quiet "../$sumf.sha256") >/dev/null 2>&1; then
      nfiles=$((nfiles + $(wc -l <"$check/$top/files/$sumf.sha256")))
    else
      bad "files in $sumf/ differ from $sumf.sha256: the archive is incomplete"
    fi
  done
  ok "$nfiles application and uploaded files match their SHA-256 checksums"

  # 3c. The database dump is readable by pg_restore and lists every table
  local toc tables datas
  toc="$("$PG_BIN/pg_restore" --list "$check/$top/database.dump" 2>/dev/null)" ||
    { bad "pg_restore cannot read database.dump"; return; }
  tables="$(grep -c ' TABLE public ' <<<"$toc")"
  datas="$(grep -c ' TABLE DATA public ' <<<"$toc")"
  if [ "$tables" -gt 0 ] && [ "$tables" -eq "$datas" ]; then
    ok "database.dump is readable: $tables tables, each with its data"
  else
    bad "database.dump has $tables tables but $datas with data"
  fi

  # 3d. Row counts inside the dump equal the counts written at backup time
  local now
  now="$(count_dump_rows "$check/$top/database.dump")"
  if [ "$now" = "$(cat "$check/$top/table-counts.txt")" ]; then
    ok "row counts in the dump match table-counts.txt ($(awk -F'|' '{s+=$2} END {print s+0}' <<<"$now") rows)"
  else
    bad "row counts in the dump differ from table-counts.txt"
  fi
}

count_dump_rows() {  # prints "table|rows" for every table in a dump, sorted
  "$PG_BIN/pg_restore" --data-only --file=- "$1" 2>/dev/null | awk '
    /^COPY / { t = $2; sub(/^public\./, "", t); gsub(/"/, "", t); n = 0; inside = 1; next }
    inside && /^\\\.$/ { print t "|" n; inside = 0; next }
    inside { n++ }' | LC_ALL=C sort
}

# ---------------------------------------------------------------------
# 4. --list and --verify modes
# ---------------------------------------------------------------------
WORK="$(mktemp -d /tmp/cart-ni-isko-backup.XXXXXX)"

if [ "$MODE" = "list" ]; then
  say "Backups in $BACKUP_DIR (newest first)"
  ls -1t "$BACKUP_DIR"/cart-ni-isko-backup-*.tar.gz 2>/dev/null |
    while read -r f; do printf '  %-48s %6s  %s\n' "$(basename "$f")" \
      "$(du -h "$f" | cut -f1)" "$(date -r "$f" '+%F %T')"; done
  [ -n "$(ls "$BACKUP_DIR"/cart-ni-isko-backup-*.tar.gz 2>/dev/null)" ] || echo "  (none yet)"
  exit 0
fi

if [ "$MODE" = "verify" ]; then
  [ -f "$VERIFY_FILE" ] || die "$VERIFY_FILE not found (see: sudo ./$SCRIPT_NAME --list)"
  verify_archive "$(readlink -f "$VERIFY_FILE")"
  if [ "$FAILS" -eq 0 ]; then
    log_line "VERIFY OK file=$(basename "$VERIFY_FILE")"
    echo "SUCCESS: $(basename "$VERIFY_FILE") is complete and readable."; exit 0
  fi
  log_line "VERIFY FAIL file=$(basename "$VERIFY_FILE") fails=$FAILS"
  echo "FAILURE: $FAILS check(s) failed. Do not rely on this backup."; exit 3
fi

# ---------------------------------------------------------------------
# 5. Read the database settings from db.conf (root, mode 600)
# ---------------------------------------------------------------------
ENV_FILE="$APP_DIR/backend/.env"
[ -f "$ENV_FILE" ] || die "$ENV_FILE not found. Run Script 1 first."
load_db

# The password goes into a temporary pgpass file (mode 600), never on a
# command line, where any user could see it with ps.
esc() { printf '%s' "$1" | sed 's/[\\:]/\\&/g'; }
printf '%s:%s:%s:%s:%s\n' "$(esc "$DB_HOST")" "${DB_PORT:-5432}" "$(esc "$DB_DATABASE")" \
  "$(esc "$DB_USERNAME")" "$(esc "$DB_PASSWORD")" >"$WORK/pgpass"
unset DB_PASSWORD PGPASSWORD PGSERVICE PGSERVICEFILE   # use only the values above
export PGPASSFILE="$WORK/pgpass" PGHOST="$DB_HOST" PGPORT="${DB_PORT:-5432}" \
       PGDATABASE="$DB_DATABASE" PGUSER="$DB_USERNAME" PGSSLMODE="${DB_SSLMODE:-require}" \
       PGCONNECT_TIMEOUT=15
PSQL=("$PG_BIN/psql" -X -A -t -v ON_ERROR_STOP=1)

# ---------------------------------------------------------------------
# 6. Pre-flight: database answers, versions fit, enough disk
# ---------------------------------------------------------------------
say "Checking the database connection ($DB_USERNAME at $DB_HOST)"
SERVER_NUM="$("${PSQL[@]}" -c 'SHOW server_version_num' 2>"$WORK/err")" ||
  die "cannot reach the database: $(errline)"
SERVER_MAJOR=$((SERVER_NUM / 10000))
DUMP_MAJOR="$("$PG_BIN/pg_dump" --version | grep -oE '[0-9]+' | head -1)"
[ "$DUMP_MAJOR" -ge "$SERVER_MAJOR" ] ||
  die "pg_dump $DUMP_MAJOR is older than the server ($SERVER_MAJOR): install postgresql-client-$SERVER_MAJOR and set PG_BIN=/usr/lib/postgresql/$SERVER_MAJOR/bin"
ok "database answers: PostgreSQL $SERVER_MAJOR (pg_dump $DUMP_MAJOR)"

FREE_MB="$(df -Pm "$BACKUP_DIR" | awk 'NR==2 {print $4}')"
[ "$FREE_MB" -ge "$BACKUP_MIN_FREE_MB" ] ||
  die "only $FREE_MB MB free in $BACKUP_DIR (need $BACKUP_MIN_FREE_MB MB): delete old backups or grow the disk"
ok "$FREE_MB MB free in $BACKUP_DIR"

# ---------------------------------------------------------------------
# 7. Make the backup in a staging folder
# ---------------------------------------------------------------------
NAME="cart-ni-isko-backup-$STAMP"
STAGE="$WORK/$NAME"
mkdir -p "$STAGE/files"

# 7a. Live row counts, read just before the dump (compared in step 9)
say "Counting the rows in every table"
"${PSQL[@]}" -F'|' >"$WORK/live-counts.txt" 2>"$WORK/err" <<'SQL' || die "counting rows failed: $(errline)"
SELECT format('SELECT %L, count(*) FROM public.%I', table_name, table_name)
FROM information_schema.tables
WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
ORDER BY table_name \gexec
SQL
LC_ALL=C sort -o "$WORK/live-counts.txt" "$WORK/live-counts.txt"
TABLES="$(wc -l <"$WORK/live-counts.txt")"
[ "$TABLES" -gt 0 ] || die "the public schema has no tables: is DB_USERNAME the right project?"
ok "$TABLES tables, $(awk -F'|' '{s+=$2} END {print s+0}' "$WORK/live-counts.txt") rows"

# 7b. The database dump (custom format: compressed, readable by pg_restore)
say "Dumping the database (pg_dump, public schema with data)"
"$PG_BIN/pg_dump" --format=custom --schema=public --no-owner --no-privileges \
  --file="$STAGE/database.dump" 2>"$WORK/err" || die "pg_dump failed: $(errline)"
count_dump_rows "$STAGE/database.dump" >"$STAGE/table-counts.txt"
ok "database.dump written ($(du -h "$STAGE/database.dump" | cut -f1))"

# 7c. Files: application code, secrets, uploads and Script 1's server settings
say "Copying the application files, .env, uploads and server settings"
copy_app "$STAGE/files/app" || die "copying the application files from $APP_DIR failed"
make_sums "$STAGE/files/app" "$STAGE/files/app.sha256"
cp -p "$ENV_FILE" "$STAGE/files/backend.env"
cp -p "$CONF" "$STAGE/files/cart-ni-isko.conf"
if [ -d "$APP_DIR/backend/storage/app" ]; then
  cp -a "$APP_DIR/backend/storage/app" "$STAGE/files/storage-app"
  make_sums "$STAGE/files/storage-app" "$STAGE/files/storage-app.sha256"
else
  warn "$APP_DIR/backend/storage/app not found: no uploaded files backed up"
fi
mkdir -p "$STAGE/files/nginx" "$STAGE/files/systemd"
for f in /etc/nginx/sites-available/cart-ni-isko*; do [ -f "$f" ] && cp -p "$f" "$STAGE/files/nginx/"; done
for f in /etc/systemd/system/cart-ni-isko-*.service; do [ -f "$f" ] && cp -p "$f" "$STAGE/files/systemd/"; done
ok "$(find "$STAGE/files" -type f | wc -l) files copied"

# 7d. MANIFEST: what is in this backup and where it came from
COMMIT="$(git -c safe.directory='*' -C "$APP_SRC" rev-parse --short HEAD 2>/dev/null || echo unknown)"
{
  echo "Cart ni Isko backup $NAME"
  echo "made:      $(date '+%F %T %Z') on $(hostname)"
  echo "database:  $DB_USERNAME at $DB_HOST (PostgreSQL $SERVER_MAJOR), $TABLES tables"
  echo "app:       $APP_DIR, repository commit $COMMIT"
  echo "contents:  database.dump (pg_dump custom format), table-counts.txt,"
  echo "           files/app (code, $(wc -l <"$STAGE/files/app.sha256") files), files/storage-app (uploads),"
  echo "           files/*.sha256 (checksum of every file), .env, config, Nginx, systemd"
  echo "restore:   Script 3 (cart-ni-isko-restore.sh)"
  echo "WARNING:   holds passwords and customer personal data. Keep it private (RA 10173)."
  echo
  echo "files:"
  (cd "$STAGE" && find . -type f ! -name MANIFEST.txt ! -path './files/app/*' ! -path './files/storage-app/*' |
     LC_ALL=C sort | sed 's|^\./|  |')
} >"$STAGE/MANIFEST.txt"

# ---------------------------------------------------------------------
# 8. Pack into one archive with a checksum
# ---------------------------------------------------------------------
say "Packing $NAME.tar.gz"
ARCHIVE="$BACKUP_DIR/$NAME.tar.gz"
tar -czf "$ARCHIVE" -C "$WORK" "$NAME" || die "tar failed while writing $ARCHIVE"
(cd "$BACKUP_DIR" && sha256sum "$NAME.tar.gz" >"$NAME.tar.gz.sha256")
chmod 600 "$ARCHIVE" "$ARCHIVE.sha256"
SIZE="$(du -h "$ARCHIVE" | cut -f1)"
ok "$ARCHIVE ($SIZE)"

# ---------------------------------------------------------------------
# 9. Verify the new archive
# ---------------------------------------------------------------------
verify_archive "$ARCHIVE"
if [ "$(cat "$WORK/live-counts.txt")" = "$(cat "$STAGE/table-counts.txt")" ]; then
  ok "row counts in the dump match the live database"
else
  warn "row counts changed during the backup (someone used the site); the dump is still consistent"
fi
if [ "$(sha256sum <"$ENV_FILE")" = "$(sha256sum <"$STAGE/files/backend.env")" ]; then
  ok ".env in the backup is identical to $ENV_FILE"
else
  bad ".env in the backup differs from $ENV_FILE"
fi

# ---------------------------------------------------------------------
# 10. Delete old backups (keep at least BACKUP_MIN_KEEP)
# ---------------------------------------------------------------------
if [ "$FAILS" -gt 0 ]; then
  say "Not deleting old backups, because this one failed verification"
elif [ "$PRUNE" = "yes" ]; then
  say "Removing backups older than $BACKUP_KEEP_DAYS days (keeping the newest $BACKUP_MIN_KEEP)"
  removed=0
  while read -r old; do
    rm -f -- "$old" "$old.sha256"; echo "  removed $(basename "$old")"; removed=$((removed + 1))
  done < <(ls -1t "$BACKUP_DIR"/cart-ni-isko-backup-*.tar.gz | tail -n +"$((BACKUP_MIN_KEEP + 1))" |
           while read -r f; do [ -n "$(find "$f" -mtime +"$BACKUP_KEEP_DAYS")" ] && echo "$f"; done)
  ok "$removed old backup(s) removed, $(ls "$BACKUP_DIR"/cart-ni-isko-backup-*.tar.gz | wc -l) kept"
fi

# ---------------------------------------------------------------------
# 11. Optional: run every day with a systemd timer
# ---------------------------------------------------------------------
if [ "$TIMER" = "yes" ]; then
  say "Installing the daily backup timer ($BACKUP_TIME)"
  install -o root -g root -m 750 "$0" /usr/local/sbin/cart-ni-isko-backup.sh
  cat >/etc/systemd/system/cart-ni-isko-backup.service <<EOF
[Unit]
Description=Cart ni Isko backup and verify (Script 2)
Wants=network-online.target
After=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/cart-ni-isko-backup.sh
EOF
  cat >/etc/systemd/system/cart-ni-isko-backup.timer <<EOF
[Unit]
Description=Run the Cart ni Isko backup every day at $BACKUP_TIME

[Timer]
OnCalendar=*-*-* $BACKUP_TIME:00
Persistent=true
RandomizedDelaySec=5min

[Install]
WantedBy=timers.target
EOF
  chmod 644 /etc/systemd/system/cart-ni-isko-backup.{service,timer}
  systemctl daemon-reload && systemctl enable --now cart-ni-isko-backup.timer >/dev/null 2>&1 ||
    die "could not enable cart-ni-isko-backup.timer: systemctl status cart-ni-isko-backup.timer"
  ok "next run: $(systemctl list-timers cart-ni-isko-backup.timer --no-legend | awk '{print $1, $2, $3}')"
fi

# ---------------------------------------------------------------------
# 12. Result
# ---------------------------------------------------------------------
if [ "$FAILS" -eq 0 ]; then
  log_line "BACKUP OK file=$NAME.tar.gz size=$SIZE tables=$TABLES warnings=$WARNS"
  echo "SUCCESS: backup made and verified: $ARCHIVE"
  exit 0
fi
log_line "BACKUP FAIL file=$NAME.tar.gz fails=$FAILS warnings=$WARNS"
echo "FAILURE: the backup was written but $FAILS verification check(s) failed: $ARCHIVE"
exit 3
