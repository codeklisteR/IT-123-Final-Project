#!/bin/bash
# =====================================================================
# cart-ni-isko-logsummary.sh - Script 4: Log Summary
#
# Purpose : Reads the logs of the Cart ni Isko server for a period (default:
#           the last 24 hours) and prints one short report: web traffic and
#           errors (Nginx), application errors (Laravel), backups and restores
#           (Scripts 2 and 3), SSH logins and sudo use, and service errors.
#           The report is also saved in REPORT_DIR for later comparison.
# Authors : Group G01
#           Brucelo, Alyssa Mae B.; Ebuenga, Kristel Ann B.;
#           Fenis, Austin B.; Marfil, John Marvin G.
# Usage   : sudo ./cart-ni-isko-logsummary.sh [--hours N | --days N]
#           [--output FILE] [--no-save] [--install-timer] [--help]
# Needs   : Script 1 already run. Reads logs only; changes nothing in the app.
# AI note : Drafted with help from Claude (Anthropic AI). Every line was
#           reviewed, tested and can be explained by the group (Section 5.6).
# =====================================================================

set -o pipefail          # a pipe fails if ANY command in it fails
umask 027                # reports: root can write, group adm can read

SCRIPT_NAME="$(basename "$0")"
CONF="${CARTNIISKO_CONF:-/etc/cart-ni-isko/cart-ni-isko.conf}"   # same variable as Script 1

usage() {
  cat <<EOF
Usage: sudo ./$SCRIPT_NAME [OPTION]...

Summarises the Cart ni Isko logs of a period into one report and saves it in
REPORT_DIR (default /var/log/cart-ni-isko-toolkit).

Options:
  --hours N         summarise the last N hours (default 24)
  --days N          summarise the last N days
  --output FILE     save the report to FILE instead of REPORT_DIR
  --no-save         only print the report, do not save it
  --install-timer   also run this summary every day at SUMMARY_TIME (systemd)
  -h, --help        show this help and exit

Examples:
  sudo ./$SCRIPT_NAME
  sudo ./$SCRIPT_NAME --days 7 --output ~/week-summary.txt

Exit status: 0 report made, 1 error, 2 bad option.
EOF
}

die() { echo "ERROR: $*" >&2; exit 1; }

load_config() {          # same rules as Scripts 1 to 3
  [ -f "$CONF" ] || die "$CONF not found. Run Script 1 (cart-ni-isko-install.sh) first."
  [ "$(stat -c '%U:%a' "$CONF")" = "root:600" ] ||
    die "$CONF must be owner root, mode 600: sudo chown root:root $CONF && sudo chmod 600 $CONF"
  # shellcheck source=/dev/null
  . "$CONF"
  APP_DIR="${APP_DIR:-/var/www/cart-ni-isko}"
  APP_NAME="${APP_NAME:-cart-ni-isko}"
  WEB_USER="${WEB_USER:-www-data}"; WEB_GROUP="${WEB_GROUP:-www-data}"
  LOG_DIR="${LOG_DIR:-${REPORT_DIR:-/var/log/cart-ni-isko-toolkit}}"   # Script 1 creates REPORT_DIR
  REPORT_DIR="${REPORT_DIR:-$LOG_DIR}"
  REPORT_KEEP_DAYS="${REPORT_KEEP_DAYS:-30}"
  SUMMARY_TIME="${SUMMARY_TIME:-06:00}"
  PHP_VER="${PHP_VER:-8.5}"
  NGINX_ACCESS_LOG="${NGINX_ACCESS_LOG:-/var/log/nginx/${APP_NAME}_access.log}"   # as Script 1 names them
  NGINX_ERROR_LOG="${NGINX_ERROR_LOG:-/var/log/nginx/${APP_NAME}_error.log}"
  SERVICES="${SERVICES:-php$PHP_VER-fpm nginx $APP_NAME-scheduler}"
}

# ---------------------------------------------------------------------
# 1. Options
# ---------------------------------------------------------------------
HOURS=24; OUTPUT=""; SAVE="yes"; TIMER="no"
need_number() { [[ "${2:-}" =~ ^[1-9][0-9]*$ ]] || { echo "ERROR: $1 needs a whole number" >&2; usage >&2; exit 2; }; }
while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help)       usage; exit 0 ;;
    --hours)         need_number "$1" "${2:-}"; HOURS="$2"; shift ;;
    --days)          need_number "$1" "${2:-}"; HOURS=$(( $2 * 24 )); shift ;;
    --output)        [ -n "${2:-}" ] || { echo "ERROR: --output needs a FILE" >&2; usage >&2; exit 2; }
                     OUTPUT="$2"; shift ;;
    --no-save)       SAVE="no" ;;
    --install-timer) TIMER="yes" ;;
    *)               echo "ERROR: unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

# ---------------------------------------------------------------------
# 2. Requirement checks
# ---------------------------------------------------------------------
[ "$(id -u)" -eq 0 ] || die "this script must be run as root (the logs are root-only): sudo ./$SCRIPT_NAME"
load_config
for t in awk sort uniq zcat date; do
  command -v "$t" >/dev/null || die "the command '$t' is missing"
done
[[ "$SUMMARY_TIME" =~ ^([01][0-9]|2[0-3]):[0-5][0-9]$ ]] || die "SUMMARY_TIME must look like 06:00 in $CONF"
[[ "$REPORT_KEEP_DAYS" =~ ^[0-9]+$ ]] || die "REPORT_KEEP_DAYS must be a whole number in $CONF"

# ---------------------------------------------------------------------
# 3. The period, written in each log's own time format
# ---------------------------------------------------------------------
START_ISO="$(date -d "-$HOURS hours" '+%F %T')"        # 2026-11-24 10:15:00 (Laravel, toolkit)
START_NUM="$(date -d "-$HOURS hours" '+%Y%m%d%H%M%S')" # 20261124101500 (Nginx, after conversion)
NOW_ISO="$(date '+%F %T')"

# ---------------------------------------------------------------------
# 4. Helpers
# ---------------------------------------------------------------------
logcat() {    # logcat FILE: prints FILE and its rotated copies, oldest first
  local f
  for f in $(ls -1r "$1".*.gz 2>/dev/null); do zcat -f "$f"; done
  [ -f "$1.1" ] && cat "$1.1"
  [ -f "$1" ] && cat "$1"
  return 0
}
top() {       # top N: counts identical input lines, prints the N most common
  sort | uniq -c | sort -rn | head -n "$1" | awk '{c=$1; $1=""; printf "    %6d %s\n", c, substr($0,2)}'
}
section() { printf '\n== %s\n' "$*"; }
line()    { printf '  %-28s %s\n' "$1" "$2"; }
none()    { echo "    (none)"; }

# Nginx access lines from the period. Combined log format:
# IP - USER [25/Nov/2026:10:15:00 +0800] "GET /path HTTP/1.1" 200 1234 "ref" "agent"
nginx_access() {
  logcat "$NGINX_ACCESS_LOG" | awk -v start="$START_NUM" '
    BEGIN { split("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec", m, " ")
            for (i = 1; i <= 12; i++) mon[m[i]] = sprintf("%02d", i) }
    { t = substr($4, 2)                       # 25/Nov/2026:10:15:00
      split(t, d, /[\/:]/)
      if ((d[3] mon[d[2]] d[1] d[4] d[5] d[6]) >= start) print }'
}

# ---------------------------------------------------------------------
# 5. The report
# ---------------------------------------------------------------------
report() {
  echo "Cart ni Isko log summary"
  echo "Period : $START_ISO  to  $NOW_ISO  ($HOURS hours)"
  echo "Server : $(hostname), made by $SCRIPT_NAME"

  # 5a. Web traffic (Nginx access log)
  section "Web traffic ($NGINX_ACCESS_LOG)"
  if [ -f "$NGINX_ACCESS_LOG" ]; then
    nginx_access >"$WORK/access"
    line "Requests" "$(wc -l <"$WORK/access")"
    line "Different visitors (IPs)" "$(awk '{print $1}' "$WORK/access" | sort -u | wc -l)"
    line "Status 2xx / 3xx" "$(awk '$9 ~ /^2/' "$WORK/access" | wc -l) / $(awk '$9 ~ /^3/' "$WORK/access" | wc -l)"
    line "Status 4xx (client errors)" "$(awk '$9 ~ /^4/' "$WORK/access" | wc -l)"
    line "Status 5xx (server errors)" "$(awk '$9 ~ /^5/' "$WORK/access" | wc -l)"
    echo "  Busiest pages:"
    awk '{split($7, p, "?"); print p[1]}' "$WORK/access" | top 5 | grep . || none
    echo "  Most active visitors:"
    awk '{print $1}' "$WORK/access" | top 5 | grep . || none
    echo "  Pages that gave 5xx errors:"
    awk '$9 ~ /^5/ {split($7, p, "?"); print $9, p[1]}' "$WORK/access" | top 5 | grep . || none
    echo "  Pages that gave 4xx errors:"
    awk '$9 ~ /^4/ {split($7, p, "?"); print $9, p[1]}' "$WORK/access" | top 5 | grep . || none
    echo "  Busiest hour:"
    awk '{print substr($4, 2, 14) ":00"}' "$WORK/access" | top 1 | grep . || none
  else
    echo "  $NGINX_ACCESS_LOG not found (set NGINX_ACCESS_LOG in $CONF)"
  fi

  # 5b. Nginx errors. Format: 2026/11/25 10:15:00 [error] 123#123: *4 message
  section "Web server errors ($NGINX_ERROR_LOG)"
  if [ -f "$NGINX_ERROR_LOG" ]; then
    logcat "$NGINX_ERROR_LOG" | awk -v start="$START_NUM" '
      { t = $1 $2; gsub(/[\/:]/, "", t); if (t >= start) print }' >"$WORK/nerr"
    line "Lines" "$(wc -l <"$WORK/nerr")"
    echo "  By level:"
    awk '{print $3}' "$WORK/nerr" | tr -d '[]' | top 5 | grep . || none
    echo "  Most common messages:"
    sed -E 's/^[^]]*\] [0-9]+#[0-9]+: (\*[0-9]+ )?//; s/, client:.*//' "$WORK/nerr" | cut -c1-90 | top 3 | grep . || none
  else
    echo "  $NGINX_ERROR_LOG not found (set NGINX_ERROR_LOG in $CONF)"
  fi

  # 5c. Laravel. Format: [2026-11-25 10:15:00] production.ERROR: message
  section "Application (Laravel) log"
  : >"$WORK/lara"
  for f in "$APP_DIR"/backend/storage/logs/laravel*.log; do
    [ -f "$f" ] && grep -E '^\[[0-9]{4}-[0-9]{2}-[0-9]{2} ' "$f" |
      awk -v start="$START_ISO" 'substr($0, 2, 19) >= start' >>"$WORK/lara"
  done
  line "Entries" "$(wc -l <"$WORK/lara")"
  echo "  By level:"
  sed -E 's/^\[[^]]*\] [a-z]+\.([A-Z]+):.*/\1/' "$WORK/lara" | top 8 | grep . || none
  echo "  Most common errors:"
  grep -E '\.(ERROR|CRITICAL|ALERT|EMERGENCY):' "$WORK/lara" |
    sed -E 's/^\[[^]]*\] [a-z]+\.[A-Z]+: //; s/ \{.*//' | cut -c1-90 | top 5 | grep . || none

  # 5d. Backups and restores (Scripts 2 and 3)
  section "Backups and restores ($LOG_DIR)"
  for name in backup restore; do
    f="$LOG_DIR/$name.log"; num=2; [ "$name" = restore ] && num=3
    if [ -f "$f" ]; then
      awk -v start="$START_ISO" 'substr($0, 1, 19) >= start' "$f" >"$WORK/$name"
      echo "  $name.log:"
      awk '{ if ($3 == "ERROR" || $3 == "CANCELLED") print $3; else print $3, $4 }' "$WORK/$name" | top 6 | grep . || none
      err="$(grep ' ERROR ' "$WORK/$name" | tail -n 1 | cut -c1-110)"
      [ -n "$err" ] && echo "    last error: $err"
    else
      echo "  $name.log: not found (Script $num has not run yet)"
    fi
  done
  last="$(grep -h 'BACKUP OK' "$LOG_DIR/backup.log" 2>/dev/null | tail -n 1)"
  line "Last good backup" "$( [ -n "$last" ] && echo "${last:0:19}" || echo 'none yet')"

  # 5e. Security: SSH logins and sudo
  section "Logins and administrator use"
  { journalctl -q --no-pager -o short-iso --since "$START_ISO" -t sshd -t sshd-session -t sudo 2>/dev/null
    awk -v start="$START_ISO" '{t = substr($1, 1, 19); sub("T", " ", t); if (t >= start) print}' \
      /var/log/auth.log 2>/dev/null
  } | sort -u >"$WORK/auth"
  line "Failed SSH logins" "$(grep -cE 'Failed password|Invalid user' "$WORK/auth")"
  line "Successful SSH logins" "$(grep -cE 'Accepted (password|publickey)' "$WORK/auth")"
  echo "  Failed logins by address:"
  grep -E 'Failed password|Invalid user' "$WORK/auth" | grep -oE 'from [0-9a-fA-F.:]+' | top 5 | grep . || none
  echo "  Successful logins:"
  grep -E 'Accepted (password|publickey)' "$WORK/auth" | sed -E 's/.*Accepted [a-z]+ for ([^ ]+) from ([^ ]+).*/\1 from \2/' | top 5 | grep . || none
  echo "  sudo commands by user:"
  grep -E 'sudo(\[[0-9]+\])?: +[^ ]+ : .*COMMAND=' "$WORK/auth" | sed -E 's/.*sudo(\[[0-9]+\])?: +([^ ]+) : .*/\2/' | top 5 | grep . || none

  # 5f. Service errors recorded by systemd
  section "Service errors (systemd journal)"
  for u in $SERVICES "$APP_NAME-backup"; do
    n="$(journalctl -q --no-pager -u "$u" -p err --since "$START_ISO" 2>/dev/null | wc -l)"
    line "$u" "$n error line(s)"
  done
  echo
  echo "End of summary."
}

# ---------------------------------------------------------------------
# 6. Make, show and save the report
# ---------------------------------------------------------------------
WORK="$(mktemp -d /tmp/cart-ni-isko-logsummary.XXXXXX)"
trap 'rm -rf -- "$WORK"' EXIT

if [ "$SAVE" = "yes" ]; then
  if [ -z "$OUTPUT" ]; then
    mkdir -p "$REPORT_DIR" && chmod 750 "$REPORT_DIR" || die "cannot create $REPORT_DIR"
    OUTPUT="$REPORT_DIR/logsummary-$(date +%Y-%m-%d_%H%M).txt"
  fi
  touch "$OUTPUT" 2>/dev/null || die "cannot write $OUTPUT"
  report | tee "$OUTPUT"
  chmod 640 "$OUTPUT"
  echo "Saved: $OUTPUT"
  # Delete saved summaries older than REPORT_KEEP_DAYS
  find "$REPORT_DIR" -maxdepth 1 -name 'logsummary-*.txt' -mtime +"$REPORT_KEEP_DAYS" -delete 2>/dev/null
else
  report
fi

# ---------------------------------------------------------------------
# 7. Optional: run every day with a systemd timer
# ---------------------------------------------------------------------
if [ "$TIMER" = "yes" ]; then
  install -o root -g root -m 750 "$0" /usr/local/sbin/cart-ni-isko-logsummary.sh
  printf '%s\n' '[Unit]' 'Description=Cart ni Isko daily log summary (Script 4)' '' \
    '[Service]' 'Type=oneshot' 'ExecStart=/usr/local/sbin/cart-ni-isko-logsummary.sh' \
    >/etc/systemd/system/cart-ni-isko-logsummary.service
  printf '%s\n' '[Unit]' "Description=Run the Cart ni Isko log summary every day at $SUMMARY_TIME" '' \
    '[Timer]' "OnCalendar=*-*-* $SUMMARY_TIME:00" 'Persistent=true' '' '[Install]' 'WantedBy=timers.target' \
    >/etc/systemd/system/cart-ni-isko-logsummary.timer
  chmod 644 /etc/systemd/system/cart-ni-isko-logsummary.{service,timer}
  systemctl daemon-reload && systemctl enable --now cart-ni-isko-logsummary.timer >/dev/null 2>&1 ||
    die "could not enable cart-ni-isko-logsummary.timer: systemctl status cart-ni-isko-logsummary.timer"
  echo "==> Daily summary timer installed ($SUMMARY_TIME); reports go to $REPORT_DIR"
fi
exit 0
